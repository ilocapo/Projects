/*
** EPITECH PROJECT, 2023
** display_h.c
** File description:
** A function to display the description
*/

#include "my_header.h"

void display_h(int ac, char **av)
{
    if (av[1][0] == '-' && av[1][1] == 'h'){
        my_putstr("--------------------------\n");
        my_putstr("         MY_HUNTER        \n");
        my_putstr("The player must shoot     \n");
        my_putstr("a bird to gain some scores\n");
        my_putstr("(+50 pts each time). The \n");
        my_putstr("game is won when you have\n");
        my_putstr("2500pts.                 \n");
        my_putstr("--------------------------\n");
    }
}
