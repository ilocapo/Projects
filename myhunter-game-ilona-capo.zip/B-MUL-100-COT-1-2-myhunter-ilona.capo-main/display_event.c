/*
** EPITECH PROJECT, 2023
** display_event.c
** File description:
** The functions for the display of my events
*/

#include <SFML/Graphics.h>
#include <SFML/Window.h>
#include <time.h>
#include <stdlib.h>
#include "my_header.h"

void display_winner(sfText **text, sfFont **font,
sfRenderWindow **window, sfSprite **sprite1)
{
    sfRenderWindow_clear(*window, sfBlack);
    sfText_setString(*text, " Winner!");
    sfText_setFont(*text, *font);
    sfText_setCharacterSize(*text, 380);
    sfRenderWindow_drawSprite(*window, *sprite1, NULL);
    sfRenderWindow_drawText(*window, *text, NULL);
}

void display_game(sfRenderWindow **window, sfSprite **sprite,
sfSprite **sprite1)
{
    sfRenderWindow_clear(*window, sfBlack);
    sfRenderWindow_drawSprite(*window, *sprite1, NULL);
    sfRenderWindow_drawSprite(*window, *sprite, NULL);
}
