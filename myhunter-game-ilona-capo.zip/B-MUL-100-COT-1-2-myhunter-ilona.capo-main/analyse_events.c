/*
** EPITECH PROJECT, 2023
** analyse_events.c
** File description:
** Functions that manage the mouse click and manage each events
*/

#include <SFML/Graphics.h>
#include <SFML/Window.h>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include "my_header.h"

int manage_mouse_click (sfMouseButtonEvent event, sfVector2f *vector,
sfSprite *sprite)
{
    sfMusic *music;
    int i = 0;
    if ((event.x <= (vector->x) + 157 && event.x >= ( vector->x) - 60) &&
    (vector->y - 100 <= event.y && event.y <= vector->y + 100) ){
        i += 50;
        vector->x = -180;
        music = sfMusic_createFromFile("ES_Slingshot-Shoot-8-SFX-Producer.ogg");
        sfMusic_play(music);
        sfSprite_setPosition(sprite, *vector);
    }else{
        i += 0;
    }
    return i;
}

int analyse_events(sfRenderWindow *window, sfEvent event, sfVector2f vector,
sfSprite *sprite)
{
    int score = 0;
    while (sfRenderWindow_pollEvent(window, &event)){
        if (event.type == sfEvtMouseButtonPressed){
            score = manage_mouse_click(event.mouseButton, &vector, sprite);
        }
        if (event.type == sfEvtKeyPressed){
            my_putstr("keyclick");
        }
        if (event.type == sfEvtClosed){
            sfRenderWindow_close(window);
        }
    }
    return score;
}
