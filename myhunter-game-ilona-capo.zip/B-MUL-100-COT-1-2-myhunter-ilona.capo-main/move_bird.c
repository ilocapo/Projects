/*
** EPITECH PROJECT, 2023
** move_bird.c
** File description:
** Functions to manage the move of the bird
*/

#include <SFML/Graphics.h>
#include <SFML/Window.h>
#include <time.h>
#include <stdlib.h>
#include "my_header.h"

void move_rect( sfIntRect * rect , int offset , int max_value )
{
    if ( rect->left < max_value){
        rect->left = rect->left + offset;
    }else{
        rect->left = 0;
    }
}

void set_image(sfTexture **texture, sfTexture **texture1,
sfSprite **sprite, sfSprite **sprite1)
{
    sfIntRect rect = {0, 0, 198, 152};
    *texture1 = sfTexture_createFromFile("back2.jpg", NULL);
    *sprite1 = sfSprite_create();
    *texture = sfTexture_createFromFile("bird.png", NULL);
    *sprite = sfSprite_create();
    sfSprite_setTexture(*sprite1, *texture1, sfTrue);
    sfSprite_setTexture(*sprite, *texture, sfTrue);
    sfSprite_setTextureRect(*sprite, rect);
}
