/*
** EPITECH PROJECT, 2023
** my_header.h
** File description:
** A header of my_hunter project
*/

#ifndef MY_HEADER
    #define MY_HEADER
    #include <SFML/Audio.h>
    #include <SFML/Graphics.h>
    #include <SFML/Window.h>
    #include <stdio.h>
    #include <time.h>
    #include <stdlib.h>

typedef struct elements{
    sfRenderWindow *w;
    sfMusic *mus;
    sfEvent event;
    sfVideoMode m;
    sfTexture *bird_t, *back_t; sfSprite *spt_b, *spt_f;
    sfIntRect rect;
    sfText *text; sfFont *font;
    sfTransformable *trans;
    sfClock *clk;
    sfTime tm;
    float sec;
    float spd;
    sfVector2f vect;
    int scr;
    sfBool loop;

}elements;

int my_putstr(char const *str);

int my_putnbr(int nb);

int manage_mouse_click (sfMouseButtonEvent event, sfVector2f *vector,
sfSprite *sprite);

int analyse_events(sfRenderWindow *window, sfEvent event,
sfVector2f vector, sfSprite *sprite);

void move_rect( sfIntRect * rect , int offset , int max_value );

void set_image(sfTexture **texture, sfTexture **texture1,
sfSprite **sprite, sfSprite **sprite1);

void display_winner(sfText **text, sfFont **font, sfRenderWindow **window,
sfSprite **sprite1);

void display_game( sfRenderWindow **window, sfSprite **sprite,
sfSprite **sprite1);

void display_h(int ac, char **av);
#endif
