/*
** EPITECH PROJECT, 2023
** my_hunter_game.c
** File description:
** My hunter game
*/

#include <SFML/Graphics.h>
#include <SFML/Window.h>
#include <time.h>
#include <stdlib.h>
#include "my_header.h"

elements *rempliss(elements *y)
{
    y = (elements*)malloc(sizeof(elements));
    sfVideoMode mode = {1920, 1080, 64};
    sfIntRect rect = {0, 0, 198, 152};
    sfVector2f vect = {0.0f, 0.0f};
    y->m = mode;
    y->rect = rect;
    y->spd = 0.5;
    y->vect = vect; y->clk = sfClock_create ();
    y->scr = 0;
    y->text = sfText_create();
    y->font = sfFont_createFromFile("CinzelDecorative-Regular.ttf");
    y->mus = sfMusic_createFromFile("ES_Birds-Peaceful-SFX-Producer.ogg");
    return y;
}

int main(int ac, char **av)
{
    elements *y; y = rempliss(y);
    ac == 2 ? display_h(ac, av) : (0);
    y->w = sfRenderWindow_create(y->m, "My_Hunter", sfResize | sfClose, NULL);
    if (!y->w) return (84);sfMusic_play(y->mus);sfMusic_setLoop(y->mus, sfTrue);
    set_image(&y->bird_t, &y->back_t, &y->spt_b, &y->spt_f);
    while (sfRenderWindow_isOpen(y->w)) {
        sfRenderWindow_setFramerateLimit(y->w, 60);
        y->scr += analyse_events(y->w, y->event, y->vect, y->spt_b);
        y->tm = sfClock_getElapsedTime(y->clk); y->sec =
        y->tm.microseconds / 1000000.0; y->scr <= 800 ? y->spd = 0.5 : (0);
        y->scr <= 1600 ? y->spd = 0.3 : (0); y->scr > 1600 ? y->spd = 0.08
        : (0); if (y->sec > y->spd) { move_rect(&y->rect, 198, 594);
            sfSprite_setTextureRect(y->spt_b, y->rect);
            y->vect.x < 2000 ? y->vect.x = y->vect.x + 50 : (0);
            if (y->vect.x == 2000) { y->vect.x = 0; y->vect.y = rand() % 800;
            } sfSprite_setPosition(y->spt_b, y->vect); sfClock_restart(y->clk);
        }y->scr != 2500 ? display_game(&y->w, &y->spt_b, &y->spt_f) :
        display_winner(&y->text, &y->font, &y->w, &y->spt_f);
        sfRenderWindow_display(y->w);
        }
}
