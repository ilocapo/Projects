/*
** EPITECH PROJECT, 2023
** pointeurs
** File description:
** flag_n
*/

#include <stdarg.h>
#include <unistd.h>

int compt_n(char const *str);

int my_putstr(char const *str);

int convert_base(unsigned int nb, int base, int n);

int my_put_adress(unsigned long long int nb, int base, int n);

int switch_ptr(char const *format, int i, va_list strg)
{
    switch (format[i + 1]) {
    case 'n' :
        int *dex = va_arg(strg,int*);
        *dex = compt_n(format);
        i += 1;
        break;
    case 'p' :
        my_putstr("0x");
        unsigned long long int ptr = va_arg(strg, unsigned long long int);
        my_put_adress(ptr,16,2);
        i += 1;
        break;
    case 'm' :
        write(2, "Success", 7);
        i += 1;
        break;
    }
    return i;
}
