/*
** EPITECH PROJECT, 2023
** third_unit_test.c
** File description:
** Unit test for flag f e and g
*/

#include <criterion/criterion.h>
#include <criterion/redirect.h>

int my_printf (char *format, ...);

int flag_e(double expo, char e);

int compt_n(char const *str);

int convert_base(unsigned int  nb, int base, int n);

void redirect_stdout(void);

Test (flag_e, trivial_case, .init = redirect_stdout) {
    flag_e(15e2, 'e');
    cr_assert_stdout_eq_str("1.500000e+03");
}

Test (compt_n, is_str_length_equal_to_len_v1) {
    char const *str = "Hello %n world";
        int len = 6;
cr_assert ( compt_n(str) == len );
}

Test (convert_base, trivial_case, .init = redirect_stdout) {
    convert_base(10,16,2);
    cr_assert_stdout_eq_str("a");
}

Test (my_printff, trivial_case, .init = redirect_stdout) {
    my_printf("%f",15.2);
    cr_assert_stdout_eq_str("15.200000");
}

Test (my_printfg, trivial_case, .init = redirect_stdout) {
    my_printf("%g",15);
    cr_assert_stdout_eq_str("0");
}
