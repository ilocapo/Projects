/*
** EPITECH PROJECT, 2023
** unit_test
** File description:
** putnbr_strlen_putstr
*/

#include <criterion/criterion.h>
#include <criterion/redirect.h>

int my_printf (char *format, ...);

int my_strlen(char const *str);

int my_putstr(char const *str);

int my_putnbr(int nbr);

void my_putchar(char c);

void redirect_stdout(void);

Test (my_putstr, trivial_case, .init = redirect_stdout){
        my_putstr("Hello World!\n");
        cr_assert_stdout_eq_str("Hello World!\n");
}

Test (my_strlen, is_str_length_equal_to_len_v1) {
    char const *str = "Hello world";
        int len = 11;
cr_assert ( my_strlen(str) == len );
}

Test (my_putnbr, trivial_case, .init = redirect_stdout) {
    my_putnbr(111);
    cr_assert_stdout_eq_str("111");
}

Test (my_putchar, trivial_case, .init = redirect_stdout) {
    my_putchar('o');
    cr_assert_stdout_eq_str("o");
}

Test (my_prinfo, trivial_case, .init = redirect_stdout){
    my_printf("%o", 8);
    cr_assert_stdout_eq_str("10");
}
