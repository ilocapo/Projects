/*
** EPITECH PROJECT, 2023
** test_myp_d.c
** File description:
** Unit test for the flag d
*/

#include <criterion/criterion.h>
#include <criterion/redirect.h>

int my_printf (char *format, ...);

void redirect_stdout(void)
{
    cr_redirect_stdout();
    cr_redirect_stderr();
}

Test (my_printfd, flag_d, .init = redirect_stdout) {
    my_printf("%d", 28);
    cr_assert_stdout_eq_str("28", "");
}

Test (my_printfc, test_flag_c, .init = redirect_stdout) {
    my_printf("%c", 'i');
    cr_assert_stdout_eq_str("i");
}

Test (my_printfs,flag_s, .init = redirect_stdout) {
    my_printf("%s", "papa");
    cr_assert_stdout_eq_str( "papa");
}

Test (my_printfm, trivial_case, .init = redirect_stdout) {
    my_printf("%m");
    cr_assert_stderr_eq_str("Success");
}
