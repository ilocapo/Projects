/*
** EPITECH PROJECT, 2023
** flag_f.c
** File description:
** This functions is specially for the flag f of printf
*/

#include <unistd.h>
#include <stdio.h>

void my_putchar(char c);

int my_putstr(char const *str);

int my_compute_power_rec (int nb, int p);

int my_putnbr(int nbr);

int flag_f( double nb, char f)
{
    double c = nb;
    int n = nb;
    my_putnbr(n);
    my_putchar('.');
    c = nb - n;
    c = c * 1000000;
    if ( n < 0){
        my_putnbr(-c + 0.0000001);
    }else{
        my_putnbr(c + 0.0000001);
    }
    return 0;
}
