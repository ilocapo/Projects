/*
** EPITECH PROJECT, 2023
** my_printf
** File description:
** base_flags
*/

#include <stdarg.h>

int convert_base(unsigned int nb, int base, int n);

int switch_base(char const *format, int i, va_list strg)
{
    switch (format[i + 1]) {
    case 'o' :
        int oct = va_arg(strg, unsigned int);
        convert_base(oct,8,1); i += 1;
        break;
    case 'u' :
        int dec = va_arg(strg, unsigned int);
        convert_base(dec,10,1); i += 1;
        break;
    case 'x' :
        int hex = va_arg(strg, unsigned int);
        convert_base(hex,16,2); i += 1;
        break;
    case 'X':
        int gex = va_arg(strg, unsigned int);
        convert_base(gex,16,1); i += 1;
        break;
    }
    return (i);
}
