/*
** EPITECH PROJECT, 2023
** my_compute_power_rec.c
** File description:
** mycompute power rec
*/

int my_compute_power_rec ( int nb , int p )
{
    int res = 1;
    if (p < 0){
        return 0;
    }else if (p == 0){
        return 1;
    }else{
        return res = (nb * (my_compute_power_rec(nb, p - 1)));
    }
}
