/*
** EPITECH PROJECT, 2023
** switch_orecision.c
** File description:
** A function to handle precision case with the print pf floating numbers
*/

#include <stdarg.h>

int flag_f_precise(float nb, char f, char point, char a);

int my_putnbr(int nb);

int switch_precision(char *format, int i, va_list strg)
{
    char a;
    switch (format[i + 1]) {
    case '.':
        if (format[i + 3] == 'f' || format[i + 3] == 'F'){
            a = format[i + 2];
            flag_f_precise(va_arg(strg,double), 'f', '.',a); i += 3;
            break;
        }else{
            my_putnbr(va_arg(strg,double) + 1); i += 2;
            break;
        }
    }
    return i;
}
