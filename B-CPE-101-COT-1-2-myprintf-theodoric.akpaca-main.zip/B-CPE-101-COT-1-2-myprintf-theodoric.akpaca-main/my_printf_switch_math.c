/*
** EPITECH PROJECT, 2023
** my_printf_switch_math.c
** File description:
** A specific function for the flag f, e and g of printf
*/

#include <stdarg.h>

int my_putnbr(int nb);

int flag_f(float nb);

int flag_e(double expo, char e);

int flag_g(double nbrg, char g);

int flag_a(double nbra, char a);

int switch_math(char *format, int i, va_list strg)
{
    switch ( format[i + 1]) {
    case 'e':
        flag_e(va_arg(strg, double), 'e'); i += 1;
        break;
    case 'E':
        flag_e(va_arg(strg, double), 'E'); i += 1;
        break;
    case 'g':
        flag_g(va_arg(strg,double), 'g'); i += 1;
        break;
    case 'G':
        flag_g(va_arg(strg,double), 'G'); i += 1;
        break;
    case 'A':
        flag_a(va_arg(strg,double), 'A'); i += 1;
        break;
    }
    return i;
}
