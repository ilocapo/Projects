/*
** EPITECH PROJECT, 2023
** flag_a.c
** File description:
** a function specific to the flag a
*/

#include <stdio.h>
#include <unistd.h>

void my_putchar(char c);

int my_putstr(char const *str);

int my_putnbr(int nbr);

int flag_f ( float nb);

double flag_e(double expo, char e);

int flag_g(double nbrg, char g);

int convert_base(unsigned int nb, int base, int n);

void cond(char a)
{
    if ( a == 'a'){
        my_putchar('x');
    }
    if (a == 'A'){
        my_putchar('X');
    }
}

void cond2(int entier, char a)
{
    if ( a == 'a'){
        convert_base(entier, 16, 2);
    }
    if ( a == 'A'){
        convert_base(entier, 16, 1);
    }
}

int flag_a(double nbra, char a)
{
    int entier, nr, i = 0, j = 0;
    float reste2, reste1 = nbra / 2;
    my_putnbr(0); cond(a);
    while ( nbra / 2 > 1.0){
        nbra /= 2; i += 1;
    }
    entier = nbra; cond2(entier, a);
    my_putchar('.'); reste2 = nbra - entier;
    for ( j = 0; reste2 > 0.09; ++j){
        reste2 *= 16; nr = reste2;
        reste2 -= nr;
        if ( a == 'a'){
            convert_base(nr, 16, 2);
        }
        if ( a == 'A'){
            convert_base(nr, 16, 1);
        }
    }
    my_putstr("p+"); my_putnbr(i);
    return 0;
}
