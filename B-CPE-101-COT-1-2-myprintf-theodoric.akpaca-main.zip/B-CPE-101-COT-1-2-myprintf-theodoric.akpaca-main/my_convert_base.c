/*
** EPITECH PROJECT, 2023
** my_convert_base.c
** File description:
** base
*/

#include <stdarg.h>
#include <unistd.h>

void my_putchar(char c);

int my_strlen(char const *str);

int convert_base(unsigned int  nb, int base, int n)
{
    int reste = nb % base;
    if (nb != 0) {
        convert_base( nb / base, base, n);
        if (reste < 10){
            my_putchar(reste + '0');
        }
        if (base > 10 && reste >= 10) {
            switch (n) {
            case 1 :
                my_putchar(reste + 55);
                break;
            case 2 :
                my_putchar(reste + 87);
                break;
            }
        }
    }
}
