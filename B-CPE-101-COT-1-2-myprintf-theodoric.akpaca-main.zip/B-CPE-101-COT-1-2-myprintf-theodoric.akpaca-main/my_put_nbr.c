/*
** EPITECH PROJECT, 2023
** my_put_nbr.c
** File description:
** my_putnbr
*/

void my_putchar(char c);
int my_putnbr(int nbr)
{
    if (nbr < -2147483647 || nbr > 2147483647){
        return 0;
    }else if (nbr < 0 && nbr > -2147483647){
        my_putchar('-');
        my_putnbr(nbr * (-1));
    }
    if ( nbr >= 0 && nbr < 10){
        my_putchar(nbr + 48);
    }else if (nbr >= 10){
        my_putnbr (nbr / 10);
        my_putnbr (nbr % 10);
    }
}
