/*
** EPITECH PROJECT, 2023
** my_p.h
** File description:
** A header for the my_printf function
*/

#ifndef MY_P_H
    #define MY_P_H

    #include <stdarg.h>

void my_putchar(char c);

int my_putstr(char const *str);

int my_putnbr(int nbr);

int switch_char( char *format, int i, va_list strg);

int switch_number(char *format, int i, va_list strg);

int switch_math(char *format, int i, va_list strg);

int switch_base(char *format, int i, va_list strg);

int switch_precision(char *format, int i, va_list strg);

int switch_ptr(char *format, int i, va_list strg);
#endif
