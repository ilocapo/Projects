/*
** EPITECH PROJECT, 2023
** my_printf.c
** File description:
** test of my_printf
*/

#include <unistd.h>
#include <stdio.h>
#include <stdarg.h>
#include "my_p.h"

int my_printf (char *format, ...)
{
    va_list strg;
    int i;
    va_start(strg, format);
    for ( i = 0; format[i] != '\0';++i){
        if (format[i] == '%' && format[i + 1] != '\0'){
            i = switch_char(format, i, strg);
            i = switch_number(format, i, strg);
            i = switch_math(format, i, strg);
            i = switch_precision(format, i, strg);
            i = switch_base(format, i, strg);
            i = switch_ptr(format, i, strg);
        }else{
            my_putchar(format[i]);
        }
    }
    va_end(strg);
    return 0;
}
