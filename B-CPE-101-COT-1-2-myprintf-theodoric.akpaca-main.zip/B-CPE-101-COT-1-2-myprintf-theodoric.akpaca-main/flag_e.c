/*
** EPITECH PROJECT, 2023
** flag_e.c
** File description:
** A function specific for the flag e of printf
*/

#include <stdio.h>
#include <unistd.h>

void my_putchar(char c);

int my_putstr(char const *str);

int my_compute_power_rec (int nb, int p);

int my_putnbr(int nbr);

int flag_f ( double nb, char f);

int condition ( int i)
{
    if ( i < 10 && i > 0){
        my_putchar('+'); my_putnbr(0); my_putnbr(i);
    }if (i < 0 && i > -10){
        my_putchar('-'); my_putnbr(0); my_putnbr(-i);
    }if ( i > 0 && i > 10){
        my_putchar('+'); my_putnbr(i);
    }if ( i < 0 && i < -10){
        my_putnbr(i);
    }
}

double flag_e(double expo, char e)
{
    int i = 0;
    if ( expo >= 10){
        for ( i = 0; expo >= 10; ++i){
            expo /= 10;
        }
        flag_f(expo + 0.0000001, 'f');
    } if (expo < 1){
        for ( i = 0; expo < 1; --i){
            expo *= 10;
        }
        flag_f(expo, 'f');
    }
    if ( e == 'e'){
        my_putchar('e');
    }else if ( e == 'E'){
        my_putchar('E');
    }
    condition (i);
}
