/*
** EPITECH PROJECT, 2023
** flag_g.c
** File description:
** A function specific to the flag f of printf
*/

#include <stdio.h>
#include <unistd.h>

void my_putchar(char c);

int my_putstr(char const *str);

int my_putnbr(int nbr);

int flag_f ( double nb, char f);

double flag_e(double expo, char e);

int flag_g(double nbrg, char g)
{
    int entier = nbrg;
    float f = nbrg;
    double exp = nbrg;
    if (nbrg != f) {
        my_putnbr(0);
    }
    if (nbrg == f ) {
        my_putnbr(nbrg);
    }
    if ( nbrg == exp && nbrg != f && g == 'g'){
        flag_e(nbrg, 'e');
    }
    if (nbrg == exp && nbrg != f && g == 'G'){
        flag_e(nbrg, 'E');
    }
    return 0;
}
