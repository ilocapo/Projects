/*
** EPITECH PROJECT, 2023
** flag_f_precision.c
** File description:
** A function for the flag f precisions
*/

#include <unistd.h>
#include <stdio.h>

void my_putchar(char c);

int my_putstr(char const *str);

int my_compute_power_rec (int nb, int p);

int my_putnbr(int nbr);

int flag_f_precise( float nb, char f, char point, char a)
{
    float c = nb, d = nb, b = nb, e;
    int n = nb;
    my_putnbr(n); my_putchar('.');
    c = nb - n;
    if (point == '.'){
        d *= my_compute_power_rec(10, a - 48 + 1);
        c *= my_compute_power_rec(10, a - 48);
        b = d - c * my_compute_power_rec(10, a - 48 + 1);
        (b >= 5) ? (e = c + 1) : (e = c);
        if ( n < 0){
            my_putnbr(-e);
        }else{
            my_putnbr(e);
        }
        return 0;
    }
}
