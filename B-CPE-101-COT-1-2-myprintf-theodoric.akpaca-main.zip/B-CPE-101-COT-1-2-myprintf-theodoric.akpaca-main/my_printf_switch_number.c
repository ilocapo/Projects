/*
** EPITECH PROJECT, 2023
** my_printf_switch_number.c
** File description:
** This function is for the flags d, i and f.
*/

#include <stdarg.h>

int my_putnbr(int nb);

int flag_f(double nb, char f);

int flag_a(double nbra, char a);

int switch_number(char *format, int i, va_list strg)
{
    switch ( format[i + 1]) {
    case 'i':
        my_putnbr(va_arg(strg, int)); i += 1;
        break;
    case 'd':
        my_putnbr(va_arg(strg, int)); i += 1;
        break;
        case 'f':
            flag_f(va_arg(strg, double), 'f'); i += 1;
        break;
    case 'F':
        flag_f(va_arg(strg, double), 'F'); i += 1;
        break;
    case 'a':
        flag_a(va_arg(strg,double), 'a'); i += 1;
        break;
    }
    return i;
}
