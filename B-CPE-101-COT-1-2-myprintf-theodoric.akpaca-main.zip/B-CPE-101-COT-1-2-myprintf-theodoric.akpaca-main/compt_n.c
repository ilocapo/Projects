/*
** EPITECH PROJECT, 2023
** compt_n
** File description:
** compt_flag_n
*/

#include <stdio.h>

int compt_n(char const *str)
{
    int i = 0;
    int t = 0;
    for (i = 0; str[i] != '%', str[i + 1] != 'n'; i++) {
        t++;
    }
    return (t);
}
