/*
** EPITECH PROJECT, 2023
** my_printf_switch_char.c
** File description:
** This function is for the flags c, s and %
*/

#include <stdarg.h>

void my_putchar(char c);

int my_putstr(char const *str);

int switch_char( char *format, int i, va_list strg)
{
    switch ( format[i + 1]) {
    case 'c':
        my_putchar(va_arg(strg, int));
        i += 1;
        break;
    case '%':
        my_putchar('%');
        i += 1;
        break;
    case 's':
        my_putstr(va_arg(strg, char *));
        i += 1;
        break;
    }
    return i;
}
