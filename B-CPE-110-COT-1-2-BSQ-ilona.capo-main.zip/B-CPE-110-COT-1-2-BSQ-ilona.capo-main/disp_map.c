/*
** EPITECH PROJECT, 2023
** disp_map.c
** File description:
** disp_map
*/

#include "my_header.h"

char *my_strcpy(char *dest, char const *src)
{
    int i = 0;
    for (i = 0; src[i] != '\0'; ++i) {
        dest[i] = src[i];
    }
    dest[i] = '\0';
    return dest;
}

char **print_map(char **map, int *sqr, char *buffer)
{
    int row_x = sqr[0], col_x = sqr[1], size = sqr[2] - 1;
    int rows = lines_s(buffer), cols = cols_s(buffer);
    int row = 0, col = 0;
    for (row = row_x; row < row_x + size && row < rows; row++) {
        for (col = col_x; col < col_x + size && col < cols; col++) {
            map[row][col] = 'x';
        }
    }
    return map;
}

void disp_map(char **map)
{
for (int row = 1; map[row] != NULL; row++) {
        my_putstr(map[row]);
    }
}
