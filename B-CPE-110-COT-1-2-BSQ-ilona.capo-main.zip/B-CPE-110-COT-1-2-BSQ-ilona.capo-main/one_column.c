/*
** EPITECH PROJECT, 2023
** one_column.c
** File description:
** one_col
*/

#include "my_header.h"

void turn_one_col(char *buffer)
{
    int cols = 1;
    int lines = lines_s(buffer), row = 0, col = 0, i = 0, j = 0;
    int k = 0;
    for (i = 0; buffer[i] != '\n'; i++) {
        j++;
        k++;
    }
    for (i = j; buffer[i] != '\0'; i++) {
            if (buffer[i] == '.') {
                buffer[i] = 'x';
                break;
            }
    }

    for (i = k + 1; buffer[i] != '\0'; i++) {
        my_putchar(buffer[i]);
    }
}
