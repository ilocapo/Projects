/*
** EPITECH PROJECT, 2023
** verif_map.c
** File description:
** verif_map
*/

#include "my_header.h"

int verif(char **map, int line)
{
int col = 0;
for (col = 0; map[line][col]; col++) {
if (map[line][col] != 'o' && map[line][col] != '.' && map[line][col] != '\n') {
                return 1;
            }
}
return 0;
}

int verif_map(char **map)
{
    for (int line = 1; map[line]; line++) {
        int check = verif(map, line);
        if (check == 1) {
            return 1;
        }
    }
    return 0;
}
