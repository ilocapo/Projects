/*
** EPITECH PROJECT, 2023
** st_compare.c
** File description:
** A function to compare two string
*/

#include <stdio.h>
#include <stdbool.h>

bool str_compare(char *src, char *str)
{
    int i = 0;
    for ( i = 0; src[i] != '\0' && str[i] != '\0'; ++i){
        if (src[i] == str[i]){
            return true;
        }
    }
    return false;
}
