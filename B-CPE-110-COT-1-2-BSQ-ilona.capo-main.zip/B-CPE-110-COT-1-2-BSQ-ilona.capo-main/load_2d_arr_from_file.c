/*
** EPITECH PROJECT, 2023
** load_2d_arr_from_file.c
** File description:
** A function to load the content of a file passed as parameter in a 2d array
*/

#include "my_header.h"

char **allocate_mem(char *buffer)
{
    int lines = lines_s(buffer), line = 0,
    col = 0, cols = cols_s(buffer), c = 0;
    char **map = malloc(sizeof(char *) * (lines + 1));
    for (; line < lines; line++) {
    map[line] = malloc(sizeof(char) * (cols + 2));
    } map[line] = NULL; return map;
}

char **turn_in_2d(char *buffer)
{
    int i = 0, col = 0, line = 0;
    int cols = cols_s(buffer), lines = lines_s(buffer);
    char **map = allocate_mem(buffer);
    for (i = 0; buffer[i] != '\0' && line < lines; i++) {
        if (buffer[i] == '\n') {
                map[line][col] = '\n';
                map[line][col + 1] = '\0';
                line += 1;
                col = 0;
        }
        if (col < cols && buffer[i] != '\n') {
                map[line][col] = buffer[i];
                col += 1;
        }
    }
    map[lines] = NULL;
    return map;
}
