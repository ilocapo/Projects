/*
** EPITECH PROJECT, 2023
** get_number.c
** File description:
** A function to turn a char string into an integer
*/

#include "my_header.h"

int get_number (char *str)
{
    int nb = 0;
    int neg = 1;
    int count = 0;
    for (count = 0; str[count] >= '0' && str[count] <= '9'; count++){
        nb = nb * 10 + (str[count] - 48);
    } if (str[0] == '-') {
        neg = -1;
    } return neg * nb;
}
