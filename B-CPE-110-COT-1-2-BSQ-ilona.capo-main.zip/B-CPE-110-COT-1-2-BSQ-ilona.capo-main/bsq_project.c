/*
** EPITECH PROJECT, 2023
** bsq_project.c
** File description:
** A program that can find in a map the biggest square possible
** without any obstacle
*/

#include "my_header.h"

int main (int ac, char **av)
{
    if ( ac != 2) {
        return 84;
    } struct stat info; stat(av[1], &info);
    if (info.st_size == 0) {
        return 84;
    } char *buffer = open_file(av);
    int lines = lines_s(buffer), cols = cols_s(buffer);
    if (lines == 2 && cols != 1) {
        turn_one_line(buffer); return 0;
    } if (lines != 2 && cols == 1) {
        turn_one_col(buffer); return 0;
    } char **map = turn_in_2d(buffer);
    if (get_number(map[0]) != (lines - 1)) {
        return 84;
    } int check = verif_map(map);
    if (check == 1) {
        return 84;
    } int *size = find_biggest_square(map, buffer);
    map = print_map(map, size, buffer);
    disp_map(map); free(buffer); return 0;
}
