/*
** EPITECH PROJECT, 2023
** open_file.c
** File description:
** open_file
*/

#include "my_header.h"

char *open_file(char **av)
{
    int line_one = 0, line = 0, i = 0, fd = 0 ;
    int size = 0;
    struct stat info; stat(av[1], &info);
    fd = open(av[1], O_RDONLY);
    char *buffer = malloc(sizeof(char) * (info.st_size + 1));
    size = read(fd, buffer, info.st_size);
    buffer[size] = '\0';
    return buffer;
}

int cols_s(char *buffer)
{
    int i = 0, j = 0;
    for (i = 0; buffer[i] != '\n'; i++);
    i++;
    for (j = 0; buffer[i] != '\n' && buffer[i] != '\0'; i++, j++);
    return j;
}

int lines_s(char *buffer)
{
    int c = 0, lines = 0;
    for (c = 0; buffer[c] != '\0'; c++) {
        if (buffer[c] == '\n')
            lines += 1;
    }
    return lines;
}
