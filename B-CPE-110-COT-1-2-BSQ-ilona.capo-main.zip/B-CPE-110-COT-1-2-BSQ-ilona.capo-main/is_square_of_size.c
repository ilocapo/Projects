/*
** EPITECH PROJECT, 2023
** is_square_of_size.c
** File description:
** a functon to see if there is a square of
** the size specified in a specific position
*/

#include "my_header.h"

int is_square_of_size(char **map, int row, int col, int size)
{
    int x_max = col + size;
    int y_max = row + size;
    int x = col, y = row;
    int n_size = 0;
    for (y = row; map[y_max] != NULL && y < y_max; y++) {
        for (x = col; map[y_max][x_max] != '\0' && x < x_max; x++) {
            map[y][x] == '.' ? n_size++ : (0);
        }
    }
    if (n_size == size *size) {
        return 1;
    } else {
        return 0;
    }
}

int bigg_size(char **map, int row, int col)
{
    int size = 1;
    int check = is_square_of_size(map, row, col, size);
    int y = 0, x = 0;
    while (check == 1) {
    size += 1;
    check = is_square_of_size(map, row, col, size);
    }
    return size;
}

int *find_biggest_square(char **map, char *buffer)
{
    int max_size = 0;
    int size = 0, row = 0, col = 0;
    int *sqr = malloc(sizeof(int) * 4);
    int check = is_square_of_size(map, row, col, size);
    sqr[0] = row, sqr[1] = col, sqr[2] = max_size;

    for (row = 0; map[row] != NULL; ++row) {
        for (col = 0; map[row][col] != '\0'; ++col) {
        size = bigg_size(map, row, col);
            if (size > max_size) {
            max_size = size;
            sqr[0] = row;
            sqr[1] = col;
            sqr[2] = max_size;
            }
        }
    }

    return sqr;
}
