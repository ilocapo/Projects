/*
** EPITECH PROJECT, 2023
** my_header.c
** File description:
** A header for the BSQ
*/

#ifndef MY_HEADER
    #define MY_HEADER

    #include <unistd.h>
    #include <stdlib.h>
    #include <sys/types.h>
    #include <sys/stat.h>
    #include <fcntl.h>
    #include <stdbool.h>

void turn_one_line(char *buffer);

bool str_compare(char *src, char *str);

void my_putchar(char c);

int my_putstr(char const *str);

int get_number (char *str);

char *open_file(char **av);

char **allocate_mem(char *buffer);

char **turn_in_2d(char *buffer);

int is_square_of_size(char **map, int row, int col, int size);

int bigg_size(char **map, int row, int col);

int cols_s(char *buffer);

int lines_s(char *buffer);

int *find_biggest_square(char **map, char *buffer);

char *my_strcpy(char *dest, char const *src);

void turn_one_col(char *buffer);

char **print_map(char **map, int *sqr, char *buffer);

int verif_map(char **map);

void disp_map(char **map);

#endif
