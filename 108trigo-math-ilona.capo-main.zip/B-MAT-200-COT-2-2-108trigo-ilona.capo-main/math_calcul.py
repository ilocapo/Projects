#!/usr/bin/python3

import sys
import math

def identity_mat(n):
    tmp = []
    for i in range(n):
        ident = []
        for j in range(n):
            ident.append(1 if j == i else 0)
        tmp.append(ident)
    return tmp

def init_mat(n, k):
    tmp = []
    for i in range(n):
        ident = []
        for j in range(n):
            ident.append(k)
        tmp.append(ident)
    return tmp

def mat_mult(mat1, mat2):
    tmp = []
    for i in range(len(mat1)):
        mult = []
        for j in range(len(mat2[0])):
            a = 0
            for k in range(len(mat1[0])):
                a += mat1[i][k] * mat2[k][j]
            mult.append(a)
        tmp.append(mult)
    return tmp

def pow_mat(mat, n):
    tmp = mat
    for i in range(n - 1):
        tmp = mat_mult(tmp, mat)
    return tmp

def div_mat(mat, k):
    for i in range(len(mat)):
        for j in range(len(mat[0])):
            mat[i][j] /= k
    return mat

def add_mat(mat1, mat2):
    tmp = []
    for i in range(len(mat1)):
        c = []
        for j in range(len(mat1[0])):
            c.append(mat1[i][j] + mat2[i][j])
        tmp.append(c)
    return tmp

def sub_mat(mat1, mat2):
    tmp = []
    for i in range(len(mat1)):
        c = []
        for j in range(len(mat1[0])):
            c.append(mat1[i][j] - mat2[i][j])
        tmp.append(c)
    return tmp


def my_exp(tab):
    tmp = identity_mat(len(tab))
    for i in range(1, 50):
        tmp = add_mat(tmp, div_mat(pow_mat(tab, i), math.factorial(i)))
    return tmp

def my_cos(tab):
    tmp = identity_mat(len(tab))
    for i in range(1, 40):
        if i % 2 == 0:
            tmp = add_mat(tmp, div_mat(pow_mat(tab, 2 * i), math.factorial(2 * i)))
        else:
            tmp = sub_mat(tmp, div_mat(pow_mat(tab, 2 * i), math.factorial(2 * i)))
    return tmp

def my_sin(tab):
    tmp = tab
    for i in range(1, 40):
        if i % 2 == 0:
            tmp = add_mat(tmp, div_mat(pow_mat(tab, 2 * i + 1), math.factorial(2 * i + 1)))
        else:
            tmp = sub_mat(tmp, div_mat(pow_mat(tab, 2 * i + 1), math.factorial(2 * i + 1)))
    return tmp

def my_cosh(tab):
    tmp = identity_mat(len(tab))
    for i in range(1, 40):
        tmp = add_mat(tmp, div_mat(pow_mat(tab, 2 * i), math.factorial(2 * i)))
    return tmp

def my_sinh(tab):
    tmp = tab
    for i in range(1, 40):
        tmp = add_mat(tmp, div_mat(pow_mat(tab, 2 * i + 1), math.factorial(2 * i + 1)))
    return tmp
