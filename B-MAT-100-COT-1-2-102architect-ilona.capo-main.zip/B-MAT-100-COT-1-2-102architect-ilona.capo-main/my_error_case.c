/*
** EPITECH PROJECT, 2023
** test
** File description:
** test*
*/

#include <stdio.h>
#include <stdlib.h>
#include "my.h"

int correct_nb_of_av(int ac, char **av)
{
    if (ac <= 4)
    exit (84);
    int nb_ac = 3;
    for (int q = 1, p = 0; q != ac ; q++) {
        if (av[q][p] == '-') {
            p++;
            if (av[q][p] == 't' || av[q][p] == 'z')
                nb_ac = nb_ac + 3;
            if (av[q][p] == 'r' || av[q][p] == 's')
                nb_ac = nb_ac + 2;
        }
        p = 0;
    }
    if (nb_ac != ac)
        exit (84);
}

int flag_cheacker(int ac, char **av)
{
    for (int q = 3, p = 0; q != ac; q++) {
        if (av[q][p] == '-') {
        q++;
        if (av[q][p] < '0' || av[q][p] > '9')
            exit (84);
        }
    }
}
