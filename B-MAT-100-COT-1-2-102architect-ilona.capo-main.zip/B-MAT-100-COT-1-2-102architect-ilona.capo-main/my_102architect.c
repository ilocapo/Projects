/*
** EPITECH PROJECT, 2023
** my_102architect.c
** File description:
** A program that print the coordonate of a point after several transformations
*/

#include "my.h"

int main (int ac, char **av)
{
    if ( ac == 2 && av[1][0] == '-' && av[1][1] == 'h'){
        my_help_displayer();
    } correct_nb_of_av(ac, av); if ( ac == 6){
        double i = atof(av[4]), j = atof(av[5]);
        double x = atof(av[1]), y = atof(av[2]);
        double **matrice = NULL;
        matrice = malloc_2d_array(3, 1);
        matrice[0][0] = x; matrice[1][0] = y; matrice[2][0] = 1;
        if ( av[3][0] == '-' && av[3][1] == 't') {
            double vector_t[3][3] = {{1, 0, i},{0, 1, j},{0, 0, 1}};
            double transl[3][1];
            transl[0][0] = matrice[0][0] * vector_t[0][0] +
            matrice[1][0] * vector_t[0][1]
            + matrice[2][0] * vector_t[0][2];
            transl[1][0] = matrice[0][0] * vector_t[1][0]
            + matrice[1][0] * vector_t[1][1]
            + matrice[2][0] * vector_t[1][2];
            transl[2][0] = 1;
            printf("Translation along vector (%s, %s)\n", av[4], av[5]);
            printf("%s\t%s\t%.2f\n%s", "1.00", "0.00", i, "0.00");
            printf("\t%s\t%.2f\n%s\t%s", "1.00", j, "0.00", "0.00");
            printf("\t%s\n", "1.00");
            printf("(%.2f, %.2f) => (%.2f, %.2f)\n", matrice[0][0],
            matrice[1][0], transl[0][0], transl[1][0]);
        } if ( av[3][0] == '-' && av[3][1] == 'z'){
            double m = atof(av[4]), n = atof(av[5]);
            double vector_z[3][3] = {{atof(av[4]), 0, 0},{0, atof(av[5]), 0},
            {0, 0, 1}};
            double scal[3][1];
            scal[0][0] = matrice[0][0] * vector_z[0][0] + matrice[1][0] *
            vector_z[0][1]
            + matrice[2][0] * vector_z[0][2];
            scal[1][0] = matrice[0][0] * vector_z[1][0] + matrice[1][0] *
            vector_z[1][1]
            + matrice[2][0] * vector_z[1][2];
            scal[2][0] = 1;
            printf("Scaling by factors %s and %s\n", av[4], av[5]);
            printf("%.2f\t%s\t%s\n%s\t%.2f", m, "0.00", "0.00", "0.00", n);
            printf("\t%s\n%s\t%s\t%s\n", "0.00", "0.00", "0.00", "1.00");
            printf("(%.2f, %.2f) => (%.2f, %.2f)\n", matrice[0][0], matrice[1][0], scal[0][0], scal[1][0]);
        }
    } if (ac == 5) {
        double x = atoi(av[1]), y = atoi(av[2]);
        double **matrice = NULL;
        matrice = malloc_2d_array(3, 1);
        matrice[0][0] = x; matrice[1][0] = y; matrice[2][0] = 1;
        if (av[3][0] == '-' && av[3][1] == 'r') {
            double têta = atoi(av[4]) / (180 / M_PI);
            double vector_r[3][3] = {{(cos(têta)), (-sin(têta)), 0},{(sin(têta)),
            (cos(têta)), 0},{0, 0, 1}};
            double rot[3][1];
            rot[0][0] = matrice[0][0] * vector_r[0][0] + matrice[1][0] * vector_r[0][1]
                + matrice[2][0] * vector_r[0][2];
            rot[1][0] = matrice[0][0] * vector_r[1][0] + matrice[1][0] * vector_r[1][1]
                + matrice[2][0] * vector_r[1][2];
            rot[2][0] = 1;
            printf("Rotation by a %s degree angle\n", av[4]);
            printf("%.2f\t%.2f\t%s\n%.2f",cos(têta) , -sin(têta), "0.00",sin(têta));
            printf("\t%.2f\t%s\n%s\t%s\t%s\n", cos(têta), "0.00", "0.00", "0.00", "1.00");
            printf("(%.2f, %.2f) => (%.2f, %.2f)\n", matrice[0][0], matrice[1][0], rot[0][0], rot[1][0]);
        }  if (av[3][0] == '-' && av[3][1] == 's') {
            double têta = (atoi(av[4]) / (180 / M_PI)) * 2;
            double vector_r[3][3] = {{(cos(têta)), (sin(têta)), 0},{(sin(têta)),(-cos(têta)), 0},{0, 0, 1}};
            double rot[3][1];
            rot[0][0] = matrice[0][0] * vector_r[0][0] + matrice[1][0] * vector_r[0][1]
                + matrice[2][0] * vector_r[0][2];
            rot[1][0] = matrice[0][0] * vector_r[1][0] + matrice[1][0] * vector_r[1][1]
                + matrice[2][0] * vector_r[1][2];
            rot[2][0] = 1;
            printf("Reflection over an axis with an inclination angle of %s degrees\n", av[4]);
            printf("%.2f\t%.2f\t%s\n%.2f",cos(têta) , sin(têta), "0.00", sin(têta));
            printf("\t%.2f\t%s\n%s\t%s\t%s\n", -cos(têta), "0.00", "0.00", "0.00", "1.00");
            printf("(%.2f, %.2f) => (%.2f, %.2f)\n", matrice[0][0], matrice[1][0], rot[0][0], rot[1][0]);
    }
    } if (ac == 8 && (av[3][0] == '-' && av[3][1] == 't') &&
    (av[6][0] == '-' && av[6][1] == 'r')){
        double x = atoi(av[1]), y = atoi(av[2]); double **matrice = NULL;
        matrice = malloc_2d_array(3, 1);
        matrice[0][0] = x; matrice[1][0] = y; matrice[2][0] = 1;
        double i = atof(av[4]), j = atof(av[5]);
        double vector_tr[3][3] = {{1, 0, i},{0, 1, j},{0, 0, 1}};
        double translr[3][1];
        translr[0][0] = matrice[0][0] * vector_tr[0][0] + matrice[1][0] * vector_tr[0][1]
        + matrice[2][0] * vector_tr[0][2];
        translr[1][0] = matrice[0][0] * vector_tr[1][0] + matrice[1][0] * vector_tr[1][1]
        + matrice[2][0] * vector_tr[1][2];
        translr[2][0] = 1;
        double têtar = atof(av[7]) / (180 / M_PI);
        double vector_rr[3][3] = {{(cos(têtar)), (-sin(têtar)), 0},{(sin(têtar)),
        (cos(têtar)), 0},{0, 0, 1}};
        double rotr[3][1];
        rotr[0][0] = translr[0][0] * vector_rr[0][0] + translr[1][0] * vector_rr[0][1]
        + translr[2][0] * vector_rr[0][2];
        rotr[1][0] = translr[0][0] * vector_rr[1][0] + translr[1][0] * vector_rr[1][1]
        + translr[2][0] * vector_rr[1][2];
        rotr[2][0] = 1;
        printf("Translation along vector (%s, %s)\nRotation by a %s degree angle\n", av[4], av[5], av[7]);
        printf("%.2f\t%.2f\t%s\n%.2f",cos(têtar), -sin(têtar) , "0.00",sin(têtar));
        printf("\t%.2f\t%s\n%s\t%s\t%s\n", cos(têtar), "0.00", "0.00", "0.00", "1.00");
        printf("(%.2f, %.2f) => (%.2f, %.2f)\n", translr[0][0], translr[1][0], rotr[1][0], rotr[0][0]);
    }
}