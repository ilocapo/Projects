/*
** EPITECH PROJECT, 2023
** test
** File description:
** test
*/

#include <stdio.h>
#include "my.h"

void my_help_displayer(void)
{
    printf("USAGE\n\t./102architect x y transfo1 arg11 [arg12] [transfo2 arg21 [arg22]]");
    printf(" ...");
    printf("\n\nDESCRIPTION\n\tx\tabcissa of the original point\n\ty");
    printf("\tordinate of the original");
    printf("point\n\n\ttransfo arg1 [arg2]\n\t-t i j\ttranslation along vector (i, j)");
    printf("\n\t-z m n\t");
    printf("scaling by factors m (x-axis) and n (y-axis)\n\t-r d\t");
    printf("rotation centered in 0 by a d");
    printf("degree angle\n\t-s d\treflection over the axis passing trough 0 with an");
    printf("inclination\n\t\t\tangle of d degrees\n");
}
