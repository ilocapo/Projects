/*
** EPITECH PROJECT, 2023
** my .h
** File description:
** test
*/

#ifndef MY_H_
    #define MY_H_
    #define M_PI    3.14159265358979323846
    #include <unistd.h>
    #include <stdlib.h>
    #include <stdio.h>
    #include <math.h>
void my_help_displayer(void);

double atof( const char * theString );

int flag_cheacker(int ac, char **av);

int correct_nb_of_av(int ac, char **av);

double atof( const char * theString );

double **malloc_2d_array(double nl, double nc);

#endif