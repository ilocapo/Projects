/*
** EPITECH PROJECT, 2023
** my_malloc.c
** File description:
** A function to allocate memory dynamically
*/

#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

double **malloc_2d_array(double nl, double nc)
{
    double **arr = NULL;
    int a = 0;
    arr = malloc(sizeof(double *) * (nl + 1));
    while ( a < nl) {
    arr[a] = malloc (sizeof(double) * (nc + 1));
    a++;
    }
    return (arr);
}