/*
** EPITECH PROJECT, 2023
** test
** File description:
** test
*/

#include "my.h"

void disp_usage(void)
{
    printf("USAGE\n");
    printf("\t./103cipher message key flag\n\n");
    printf("DESCRIPTION\n");
    printf("\tmessage\ta message, made of ASCII characters\n");
    printf("\tkey\t\tthe encryption key, made of ASCII characters\n");
    printf("\tflag\t\t0 for the message to be encrypted, 1 to be decrypted\n");
}
