/*
** EPITECH PROJECT, 2023
** test
** File description:
** test
*/

#include "my.h"

int nb_rows(int cols, int len_message)
{
    int nb_rows = (len_message / cols);

    if (len_message % cols != 0)
        nb_rows++;
    return (nb_rows);
}

int **filer_of_48(int **matrix_key, int rows)
{
    for (int i = 0; i < rows; i++)
        for (int j = 0; j < rows; j++)
            matrix_key[i][j] = 0;
    return (matrix_key);
}

int **filer_of_48_sms(int **matrix_sms, int cols, int nb_rows)
{
    for (int i = 0; i < nb_rows; i++)
        for (int j = 0; j < cols; j++)
            matrix_sms[i][j] = 0;
    return (matrix_sms);
}

int **matrix_key_filler(int size, char *key)
{
    int **matrix_key = malloc_2d_array(size, size);
    int x = 0;
    matrix_key = filer_of_48(matrix_key, size);
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            matrix_key[i][j] = key[x];
            if (key[x] == '\0')
                break;
            x++;
        }
    } return (matrix_key);
}

int **matrix_sms_filler(int size,  char *sms)
{
    int rows = nb_rows( size, my_strlen(sms));
    int **matrix_sms = malloc_2d_array(rows, size);
    int x = 0;
    matrix_sms = filer_of_48_sms(matrix_sms, size, rows);
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < size; j++) {
            matrix_sms[i][j] = sms[x];
            if (sms[x] == '\0')
                break;
            x++;
        }
    }
    return (matrix_sms);
}
