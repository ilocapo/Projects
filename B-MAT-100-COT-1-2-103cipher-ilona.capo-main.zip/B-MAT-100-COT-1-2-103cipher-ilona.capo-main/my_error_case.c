/*
** EPITECH PROJECT, 2023
** test
** File description:
** test
*/

#include "my.h"

int encrypt_error(int ac, char **av)
{
    int p = 0, q = 0;
    for (q = 1; q != 2; q++) {
        while (av[q][p] != '\0') {
            if (av[q][p] >= ' ' && av[q][p] <= '~'){
                p++;
        }else{
                return (69);
            }
        }
    } return (0);
}

int decrypt_error(int ac, char **av)
{
    int j = 0;
    while (av[1][j] != '\0') {
        if (av[1][j] >= '0' && av[1][j] <= '9' || av[1][j] == ' '){
            j++;
        } else {
            return (69);
        }
    }
    j = 0;
    while (av[2][j] != '\0') {
        if (av[2][j] >= ' ' && av[2][j] <= '~'){
            j++;
        } else {
            return (69);
        }
    } return (0);
}

int errors_case(int ac, char **av)
{
    if (ac != 4) exit (84);
    if (my_strlen(av[3]) == 1) {
        if (av[3][0] == '0') {
            if (encrypt_error(ac, av) == 69)
            exit (84);
        }
        else if (av[3][0] == '1') {
        if (decrypt_error(ac, av) == 69)
        exit (84);
        } else {
        exit (84);
        }
    } else {
        exit (84);
    }return (0);
}
