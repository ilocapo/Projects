/*
** EPITECH PROJECT, 2023
** test
** File description:
** test
*/

#include "my.h"

int main (int ac , char **av)
{
    if (ac == 2 && av[1][0] == '-' && av[1][1] == 'h') {
        disp_usage(); return (0);
    } if (ac < 2) return (84);
    errors_case(ac, av);
    if (av[3][0] == '0') {
        my_encrytping( av[1], av [2]);
    }
}
