/*
** EPITECH PROJECT, 2023
** task03
** File description:
** kiff
*/
#include <unistd.h>
#include <stdio.h>

int my_strlen(char const * str )
{
    int i = 0;
    int q = 0;
    while (str[i] != '\0') {
        i++;
    }
    return (i);
}
