/*
** EPITECH PROJECT, 2023
** tze
** File description:
** test
*/

#include "my.h"

int compute_enc(int ** matrix_key, int ** matrix_sms,
int i, int j, int matrix_nbr)
{
    int temp = 0;

    for (int z = 0; z != matrix_nbr; z++)
        temp += matrix_sms[i][z] * matrix_key[z][j];
    return (temp);
}

int **create_res_matrix(int matrix_nbr, int line_nbr)
{
    int **result_m = malloc(sizeof(int *) * line_nbr);

    for (int i = 0; i != line_nbr; i++)
        result_m[i] = malloc(sizeof(int) * matrix_nbr);
    for (int i = 0; i != line_nbr; i++)
        for (int j = 0; j != matrix_nbr; j++)
            result_m[i][j] = 0;
    return (result_m);
}

void fill_matrix (int **matrix_key, int **matrix_sms,
int matrix_nbr, int line_nbr)
{
    int **matrix_result = create_res_matrix(matrix_nbr, line_nbr);

    for (int i = 0; i != line_nbr; i++)
        for (int j = 0; j != matrix_nbr; j++)
            matrix_result[i][j] = compute_enc(matrix_key,
            matrix_sms, i, j, matrix_nbr);
    for (int i = 0; i != line_nbr; i++)
        for (int j = 0; j != matrix_nbr; j++) {
            if (i == line_nbr - 1 && j == matrix_nbr - 1) {
                printf("%d\n", matrix_result[i][j]);
                break;
            }
            printf("%d ", matrix_result[i][j]);
        }
    free(matrix_result);
}

int my_encrytping(char *sms, char *key)
{
    int matrix_nbr = ceil(sqrt(my_strlen(key)));
    int **matrix_key = matrix_key_filler(matrix_nbr, key);
    int **matrix_sms = matrix_sms_filler(matrix_nbr, sms);
    int rows = nb_rows( matrix_nbr, my_strlen(sms));
    printf("Key matrix:\n");
    for (int i = 0; i != matrix_nbr; i++) {
        for (int j = 0; j != matrix_nbr; j++) {
            if (j == matrix_nbr - 1)
                printf("%d", matrix_key[i][j]);
            else
                printf("%d\t", matrix_key[i][j]);
        }
        printf("\n");
    }   printf("\nEncrypted message:\n");
    fill_matrix(matrix_key, matrix_sms, matrix_nbr, rows);

}
