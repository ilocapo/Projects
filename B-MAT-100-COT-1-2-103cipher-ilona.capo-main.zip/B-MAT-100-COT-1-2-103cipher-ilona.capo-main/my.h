/*
** EPITECH PROJECT, 2023
** test
** File description:
** test
*/

#ifndef MY_H_
    #define MY_H_
    #include <unistd.h>
    #include <stddef.h>
    #include <math.h>
    #include <unistd.h>
    #include <stdio.h>
    #include <stdlib.h>

void disp_usage(void);

int **malloc_2d_array(int lines, int cols);

int my_strlen (char const *str);

int nb_rows(int cols, int len_message);

int **filer_of_48(int **matrix_key, int rows);

int **matrix_key_filler(int size, char *key);

int **matrix_sms_filler(int size,  char *sms);

int my_encrytping(char *sms, char *key);

int encrypt_error(int ac, char **av);

int decrypt_error(int ac, char **av);

int errors_case(int ac, char **av);
#endif
