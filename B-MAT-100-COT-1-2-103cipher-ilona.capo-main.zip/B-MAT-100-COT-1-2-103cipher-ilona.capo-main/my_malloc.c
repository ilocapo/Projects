/*
** EPITECH PROJECT, 2023
** my_malloc.c
** File description:
** A function to allocate memory dynamically
*/

#include "my.h"

int **malloc_2d_array(int lines, int cols)
{
    int **arr = NULL;
    int a = 0;
    arr = malloc(sizeof(int *) * (lines + 1));
    while (a != lines){
    arr[a] = malloc(sizeof(int) * (cols + 1));
    a++;
    }return (arr);
}
