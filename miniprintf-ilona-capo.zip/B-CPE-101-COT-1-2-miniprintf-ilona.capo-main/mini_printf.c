/*
** EPITECH PROJECT, 2023
** mini_printf.c
** File description:
** mini printf
*/

#include <unistd.h>
#include <stdarg.h>

void my_putchar(char c)
{
    write(1, &c, 1);
}

int my_putstr(char const *str)
{
    for ( int i = 0; str[i] != '\0'; ++i){
        my_putchar(str[i]);
    }
    return 0;
}

int my_putnbr(int nbr)
{
    if (nbr < -2147483647 || nbr > 2147483647){
        return 0;
    }else if (nbr < 0 && nbr > -2147483647){
        my_putchar('-');
        my_putnbr(nbr * (-1));
    }
    if ( nbr >= 0 && nbr < 10){
        my_putchar(nbr + 48);
    }else if (nbr >= 10){
        my_putnbr (nbr / 10);
        my_putnbr (nbr % 10);
    }
}

int switch_char( char *format, int i, va_list strg)
{
    switch ( format[i + 1]) {
    case 'c':
        my_putchar(va_arg(strg, int));
        i += 1;
        break;
    case '%':
        my_putchar('%');
        i += 1;
        break;
    case 's':
        my_putstr(va_arg(strg, char *));
        i += 1;
        break;
    }
    return i;
}

int switch_number(char *format, int i, va_list strg)
{
    switch ( format[i + 1]) {
    case 'i':
        my_putnbr(va_arg(strg, int));
        i += 1;
        break;
    case 'd':
        my_putnbr(va_arg(strg, int));
        i += 1;
        break;
    }
    return i;
}

int mini_printf (char *format, ...)
{
    va_list strg;
    int i;
    va_start(strg, format);
    for ( i = 0; format[i] != '\0';++i){
        if (format[i] == '%' && format[i + 1] != '\0'){
            i = switch_char(format, i, strg);
            i = switch_number(format, i, strg);
        }else{
            my_putchar(format[i]);
        }
    }
    va_end(strg);
    return 0;
}
