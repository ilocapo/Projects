/*
** EPITECH PROJECT, 2023
** my_header.h
** File description:
** a header for my program
*/

#ifndef MY_HEADER
    #define MY_HEADER
    #define N_OF_PI    3.14159265358979323846
double atof( const char * theString );

float sqrtf( float value );

typedef struct vector {
    float x, y, z;
} vector;

#endif
