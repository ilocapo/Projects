/*
** EPITECH PROJECT, 2023
** 101pong.c
** File description:
** 101 pong
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "my_header.h"
#include <stdbool.h>

int verify_if_it_reach_paddle (float z0, float z1, vector velocity,
float angle)
{
    if ( z0 == z1 || angle == 0 || angle > 90, velocity.z == 0.0){
        printf("The ball won't reach the paddle.");
    }else if ( (z0 < 0 && z1 > 0) || (z1 < 0 && z0 > 0)){
        printf("The ball won't reach the paddle.");
    }else if ( ((z0 > 0 && z1 > 0) && z0 > z1)){
        printf("The ball won't reach the paddle.");
    }else{
        printf("The incidence angle is %.2f",angle );
    }
}

int main (int ac, char **av)
{
    vector velocity, position;
    float x0, y0, z0, x1, y1, z1, norm, angle, norm_p;
    int n;
    if ( ac == 7)return 84;
    n = atoi(av[7]);
    if (ac == 8 && ac != 7 && n > 0 ){
    x0 = atof(av[1]); y0 = atof(av[2]); z0 = atof(av[3]);
    x1 = atof(av[4]); y1 = atof(av[5]); z1 = atof(av[6]);
    velocity.x = (x1 - x0); velocity.y = (y1 - y0); velocity.z = (z1 - z0);
    position.x = n * velocity.x + x1; position.y = n * velocity.y + y1;
    position.z = n * velocity.z + z1;
    norm_p = (velocity.x * velocity.x) + (velocity.y * velocity.y) +
    (velocity.z * velocity.z); norm = sqrt(norm_p);
    angle = asin(velocity.z / norm) * 180 / N_OF_PI; angle = fabs(angle);
    printf("The velocity vector of the ball is:\n(%.2f, %.2f, %.2f)\n",
    velocity.x, velocity.y, velocity.z);
    printf("At time t + %d, ball coordinates will be:\n(%.2f, %.2f, %.2f)\n",
    n, position.x, position.y, position.z);
    verify_if_it_reach_paddle(z0, z1, velocity, angle); return 0;
    }else if ( ac < 8 || ac > 8 || n < 0) {return 84;}
}
