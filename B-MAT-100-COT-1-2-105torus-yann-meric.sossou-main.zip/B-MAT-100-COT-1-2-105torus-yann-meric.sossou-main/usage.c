/*
** EPITECH PROJECT, 2023
** usage
** File description:
** explain_how_work_my_radar_programm
*/

#include "my.h"

void usage(void)
{
    my_putstr("USAGE\n");
    my_putstr("    ./105torus opt a0 a1 a2 a3 a4 n\n\n");
    my_putstr("DESCRIPTION\n");
    my_putstr("    opt        method option:\n");
    my_putstr("                   1 for the bisection method\n");
    my_putstr("                   2 for Newton's method\n");
    my_putstr("                   3 for the secant method\n");
    my_putstr("    a[0-4]         coefficients of the equation\n");
    my_putstr("    n              precision (the application of the polynomial to the solution should be smaller than 10^-n)\n");
}
