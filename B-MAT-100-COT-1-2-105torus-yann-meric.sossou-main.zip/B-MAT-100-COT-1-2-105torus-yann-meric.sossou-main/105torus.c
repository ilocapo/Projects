/*
** EPITECH PROJECT, 2023
** definition_of_function
** File description:
** compute_definition_of_function
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "my.h"

double *definition(double a, double b, double c, double d, double e, double x)
{
    double *tab = malloc(sizeof(double) * 1);
    tab[0] = (e * pow(x, 4)) + (d * pow(x, 3)) + (c * pow(x, 2)) + (b * x) + a;
    return (tab);
}

double *definition_deriv(double a, double b, double c, double d, double e, double x)
{
    double *tab = malloc(sizeof(double) * 1);
    tab[0] = (4 * e * pow(x, 3)) + (3 * d * pow(x, 2)) + (2 * c * x) + b;
    return (tab);
}

double compute_midpoint(double a, double b)
{
    double c = (a + b) / 2;
    return (c);
}

int main(int ac, char **av)
{
    
    if (ac == 2) {
        if (av[1][0] == '-' && av[1][1] == 'h') { 
            usage();return (0);
        }
    } else if (ac == 8) {
        if (atof(av[2]) == atof(av[3]) && atof(av[3]) == atof(av[4]) && atof(av[4]) == atof(av[5]) && atof(av[5]) == atof(av[6]) && atof(av[6]) == atof(av[7])) {
            return (84);
        }
        int a = 0; int b = 0;
        for (a = 1; av[a] != NULL; a++) {
            for (b = 0; av[a][b] != '\0'; b++) {
                if (av[a][b] == '-' || av[a][b] == '.' || 48 <= av[a][b] &&  av[a][b] <= 57) {
                } else return 84;
            }
        } if (av[1][0] == '1') {
            double n = atof(av[7]);
            if (n < 0) return (84);
            int i = n;
            double round = 1 / pow(10, i);
            double *answer = bisection_method(av, n);
            double bisection = round + answer[0];
            printf("x = %.*f\n", bisection, i);
        } else if (av[1][0] == '2') {
            double n = atof(av[7]);
            if (n < 0) return (84);
            int	i = n;
            double newton = newton_method(av, n);
            if (newton == 0) return (84);
            printf("x = %.*f\n", newton, i);
        } else if (av[1][0] == '3') {
            double n = atof(av[7]);
            if (n < 0) return (84);
            double secant = secant_method(av, n);
            if (secant == 0) return (84);
        } else return (84);
    } else return (84);
    return (0);
}
