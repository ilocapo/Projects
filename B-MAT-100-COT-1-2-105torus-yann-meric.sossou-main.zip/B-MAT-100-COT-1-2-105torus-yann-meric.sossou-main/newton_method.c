/*
** EPITECH PROJECT, 2023
** newton_method
** File description:
** checking_intersection_with_tors_using_newton_method
*/

#include "my.h"

double newton_method(char **av, double n)
{
    double a = 0.5; int j = n;
    double *deriv = definition_deriv(atof(av[2]), atof(av[3]), atof(av[4]), atof(av[5]), atof(av[6]), a);
    if (deriv[0] == 0) return (0);
    double *tab = definition(atof(av[2]), atof(av[3]), atof(av[4]), atof(av[5]), atof(av[6]), a);
    double next = a - (tab[0] / deriv[0]);
    double *table = definition(atof(av[2]), atof(av[3]), atof(av[4]), atof(av[5]), atof(av[6]), next);
    printf("x = %.1lf\n", a);
    while (fabs(table[0]) > pow(10, -n)) {
        a = next;
        printf("x = %.*f\n", next, j);
        deriv = definition_deriv(atof(av[2]), atof(av[3]), atof(av[4]), atof(av[5]), atof(av[6]), a);
        if (deriv[0] == 0) return (0);
        tab = definition(atof(av[2]), atof(av[3]), atof(av[4]), atof(av[5]), atof(av[6]), a);
        next = a - (tab[0] / deriv[0]);
        table = definition(atof(av[2]), atof(av[3]), atof(av[4]), atof(av[5]), atof(av[6]), next);
    } return (next);
}
