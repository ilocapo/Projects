/*
** EPITECH PROJECT, 2023
** secant_method
** File description:
** checking_intersection_with_tors_using_secant_method
*/

#include "my.h"

double secant_method(char **av, double n)
{
    double a = 0; double b = 1; int j = n;
    double *tab = definition(atof(av[2]), atof(av[3]), atof(av[4]), atof(av[5]), atof(av[6]), a);
    double *table = definition(atof(av[2]), atof(av[3]), atof(av[4]), atof(av[5]), atof(av[6]), b);
    double prod = table[0] * (b - a); double dif = table[0] - tab[0];
    if (dif == 0) return (0);
    double next = b - (prod / dif);
    if (next <= 0 || next >= 1) return (0);
    double *secant = definition(atof(av[2]), atof(av[3]), atof(av[4]), atof(av[5]), atof(av[6]), next);
    printf("x = %.1lf\n", next);
    while (fabs(secant[0]) > pow(10, -n)) {
        a = b;
        b = next;
        tab = definition(atof(av[2]), atof(av[3]), atof(av[4]), atof(av[5]), atof(av[6]), a);
        table = definition(atof(av[2]), atof(av[3]), atof(av[4]), atof(av[5]), atof(av[6]), b);
        prod = table[0] * (b - a);
        dif = table[0] - tab[0];
        if (dif == 0) return (0);
        next = b - (prod / dif);
        if (next <= 0 || next >= 1) return (0);
        secant = definition(atof(av[2]), atof(av[3]), atof(av[4]), atof(av[5]), atof(av[6]), next);
        printf("x = %.*f\n", next, j);
    } return (next);
}
