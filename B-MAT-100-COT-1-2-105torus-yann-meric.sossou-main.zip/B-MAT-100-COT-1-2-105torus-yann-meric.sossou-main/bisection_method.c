/*
** EPITECH PROJECT, 2023
** bisection_method
** File description:
** check_intersection_with_tors_using_bisection_method
*/

#include "my.h"

double *bisection_method(char **av, double n)
{
    double a = 0, b = 1;
    double *stock = malloc(sizeof(double) * 2);
    double midpoint = compute_midpoint(a, b);
    double *tab = definition(atof(av[2]), atof(av[3]), atof(av[4]), atof(av[5]), atof(av[6]), a);
    double *table = definition(atof(av[2]), atof(av[3]), atof(av[4]), atof(av[5]), atof(av[6]), midpoint);
    double solution = tab[0] * table[0];
    int i = 1; int j = n;
    while ((fabs(table[0]) > pow(10, -n))) {
        if (solution < 0) {
            stock[0] = a; stock[1] = midpoint;
            if (i == j) {
                i = j;
                printf("x = %.*f\n", stock[1], i);
            } if (i < j) {
                printf("x = %.*f\n", stock[1], i);i++;
            }
        } else {
            stock[0] = midpoint; stock[1] = b;
            if (i == j) {
                i = j;
                printf("x = %.*f\n", stock[0], i);
            } if (i < j) {
                printf("x = %.*f\n", stock[0], i);i++;
            }
        } a = stock[0]; b = stock[1]; midpoint = compute_midpoint(a, b);
        tab = definition(atof(av[2]), atof(av[3]), atof(av[4]), atof(av[5]), atof(av[6]), a);
        table = definition(atof(av[2]), atof(av[3]), atof(av[4]), atof(av[5]), atof(av[6]), midpoint);
        solution = tab[0] * table[0];
    } return (stock);
}
