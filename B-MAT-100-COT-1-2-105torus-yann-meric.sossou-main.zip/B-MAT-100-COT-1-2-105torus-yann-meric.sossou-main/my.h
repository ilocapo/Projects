/*
** EPITECH PROJECT, 2023
** my.h
** File description:
** contain_all_prototype_of_my_file.c
*/

#ifndef MY_H_
    #define MY_H_
    #include <stdio.h>
    #include <stdlib.h>
    #include <math.h>

void usage(void);

void my_putchar(char c);

int main(int ac, char **av);

int my_putstr(char const *str);

double newton_method(char **av, double n);

double secant_method(char **av, double n);

double compute_midpoint(double a, double b);

double *bisection_method(char **av, double n);

double *definition(double a, double b, double c, double d, double e, double x);

double *definition_deriv(double a, double b, double c, double d, double e, double x);

#endif
