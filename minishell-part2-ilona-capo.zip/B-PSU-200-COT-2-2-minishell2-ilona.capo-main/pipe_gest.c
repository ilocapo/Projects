/*
** EPITECH PROJECT, 2023
** pipe_gest.c
** File description:
** pipe_gest
*/

#include "minishell.h"

void exec_command(char **pth, char **env, env_t *list)
{
    int pid = fork();
    int status;
    if (pid = 0) {
        conditions(pth, pth[0], env, list);
    } if (pid != 0 && pid > 0) {
        waitpid(pid, &status, 0);
    } if (pid < 0) {
        write(2, "Error de creation du proces\n", 29);
    }
}

void exec_pipe(char **left_pth, char **right_pth, char **env, env_t *list)
{
    int p_fd[2]; if (pipe(p_fd) == -1) {
        write(2, "Error de creation du pipe\n", 27); return;
    } int n_pid1 = fork();
    if (n_pid1 == 0) {
        close(p_fd[0]); dup2(p_fd[1], 1);
        close(p_fd[1]); conditions(left_pth, left_pth[0], env, list);
    } if (n_pid1 < 0) {
        write(2, "Erreur de creation du processus enfant1\n", 41); return;
    } int pid2 = fork();
    if (pid2 == 0) {
        close(p_fd[1]); dup2(p_fd[0], 0);
        close(p_fd[0]);
        conditions(right_pth, right_pth[0], env, list);
    } if (pid2 < 0) {
    write(2, "Erreur de creation du processus enfant2\n", 41);
    return;
    } close(p_fd[0]); close(p_fd[1]);
    waitpid(n_pid1, NULL, 0); waitpid(pid2, NULL, 0);
}
