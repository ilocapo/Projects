/*
** EPITECH PROJECT, 2023
** set_env.c
** File description:
** set_env
*/
#include "minishell.h"

int check_pathf(char *path)
{
    int checkf = 0;
    if (path[0] == '_' || (path[0] >= 'A' && path[0] <= 'Z')) {
        checkf += 1;
    } if (path[0] == '_' || (path[0] >= 'a' && path[0] <= 'z')) {
        checkf += 1;
    }
    return checkf;
}

int check_path(char *path)
{
    int check = 0;
    int index = 0;
    for (index = 1; path[index] != '\0'; index++) {
    if (path[index] >= 'A' && path[index] <= 'Z') {
        check += 1;
    } if (path[index] <= 'a' && path[index] >= 'z') {
        check += 1;
    } if (path[0] == '_') {
        check += 1;
    }
    }
    return check;
}

env_t *set_env(char **path, char **env, env_t *list)
{
    int checkf = check_pathf(path[1]);
    int check = check_path(path[1]);
        if ( checkf == 1 && check > 0) {
    int index = 0;
    int len = my_strlen(path[1]) + my_strlen(path[2]) + 1;
    char *new = malloc(sizeof(char) * (len + 1));
    new = my_strcat(path[1], "=");
    new = my_strcat(new, path[2]);
    add_at_end(list, new);
    return list;
    } if (checkf == 0) {
        write (1, "setenv: Variable name must begin with a letter.\n", 49);
        return list;
    } if (check == 0) {
        write(1, "setenv: Variable name must contain alphanumeric ", 49);
        write(1, "characters.\n", 13);
        return list;
    }
}

env_t *set_env2(char **path, char **env, env_t *list)
{
    int checkf = check_pathf(path[1]);
    int check = check_path(path[1]);
    if ( checkf == 1 && check > 0) {
    int index = 0;
    int len = my_strlen(path[1]) + 1;
    char *new = malloc(sizeof(char) * (len + 1));
    new = my_strcat(path[1], "=");
    add_at_end(list, new);
    return list;
    } if (checkf == 0) {
        write (1, "setenv: Variable name must begin ", 34);
        write(1, "with a letter.\n", 16);
        return list;
    } if (check == 0) {
        write(1, "setenv: Variable name must contain ", 36);
        write(1, "alphanumeric characters.\n", 26);
        return list;
    }
}
