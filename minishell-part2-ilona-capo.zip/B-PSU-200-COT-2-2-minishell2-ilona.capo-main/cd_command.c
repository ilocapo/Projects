/*
** EPITECH PROJECT, 2023
** cd_command.c
** File description:
** cd_command
*/

#include "minishell.h"


char *find_home(char **env)
{
    int i = 0;
    char *temp = malloc(sizeof(char) * 95);
    for (i = 0; env[i] != NULL; i++) {
        if (!str_ncompare("OLDPWD=", env[i], 7)) {
            temp = my_strcpy(temp, env[i]);
            break;
        }
    } return temp;
}

void check_existing_file(DIR *dir, char **args)
{
    dir = opendir (args[1]);
    if (dir == NULL) {
    my_putstr(args[1]); my_putstr(": No such file or directory.\n");
    closedir(dir);
    } else {
    int change = chdir(args[1]);
    my_putstr(args[1]); closedir(dir);
    }
}

void cd_command(char **args, char **env)
{
    DIR *dir; if (args[1] == NULL) {
        char *home = find_home(env);
        char *copy = malloc(sizeof(char) *my_strlen(home) + 1);
        int index = 7, ind = 0;
        for (index = 7; home[index] != '\0'; index++) {
    copy[ind] = home[index]; ind++;
    } dir = opendir(copy); int change = chdir(copy);
    closedir(dir);
    } else if (str_compare(args[1], "..") == true) {
        dir = opendir(".."); int change = chdir("..");
        closedir(dir);
    } else {
        check_existing_file(dir, args);
    }
}

env_t *env_command(env_t *list)
{
    env_t *current = list;
    while (current != NULL) {
        my_putstr(current->env_l);
        my_putchar('\n');
        current = current->next;
    }
    return list;
}
