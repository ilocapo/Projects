/*
** EPITECH PROJECT, 2023
** my_strcat.c
** File description:
** strcat
*/

#include "minishell.h"

char *my_strcat (char *dest, char const *src)
{
    int i = 0, j = 0;
    int dest_len = my_strlen(dest);
    for ( i = 0; i < dest_len; ++i){};
    for (j = 0; src[j] != '\0';++j){
            dest[i + j] = src[j];
        }
        dest[i + j + 1] = '\0';
        return dest;
}
