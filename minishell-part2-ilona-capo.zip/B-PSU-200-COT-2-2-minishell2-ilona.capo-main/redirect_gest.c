/*
** EPITECH PROJECT, 2023
** redirect_gest.c
** File description:
** redirect.gest
*/

#include "minishell.h"

void redirect_entre(char **pth, char **file)
{
    for (int i = 0; pth[i] != NULL; i++) {
        if (str_compare(pth[i], "<")) {
            *file = pth[i + 1];
            pth[i] = NULL;
            break;
        }
    }
}

void redirect_sort(char **pth, char **outfile)
{
    for (int i = 0; pth[i] != NULL; i++) {
        if (str_compare(pth[i], ">")) {
            *outfile = pth[i + 1];
            pth[i] = NULL;
            break;
        }
    }
}

void redirect(char **pth)
{
    char *in_file = NULL;
    char *out_file = NULL;
    redirect_entre(pth, &in_file);
    redirect_sort(pth, &out_file);
    if (in_file != NULL) {
        int fd_in = open(in_file, O_RDONLY);
        if (fd_in == -1) {
            write(2, "Erreur de creation du file\n", 28); return;
        } dup2(fd_in, 0);
        close(fd_in);
    } if (out_file != NULL) {
        int fd_out = open(out_file, O_WRONLY | O_CREAT | O_TRUNC, 0666);
        if (fd_out == -1) {
            write(2, "Erreur de creation du file\n", 28); return;
        } dup2(fd_out, 1);
        close(fd_out);
    }
}
