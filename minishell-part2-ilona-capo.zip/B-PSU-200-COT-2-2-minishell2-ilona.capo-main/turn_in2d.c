/*
** EPITECH PROJECT, 2023
** turn_in2d.c.c
** File description:
** turn in 2d
*/

#include "minishell.h"

char **allocate_mem(char *buffer, char d)
{
    char **map = NULL;
    if (check_first(buffer, d) == 0) {
        map = malloc(sizeof(char *) * 2);
        map[0] = malloc(sizeof(char) * my_strlen(buffer) + 1);
        return map;
    }
    int lines = 0, line = 0, col = 0, cols = 0, c = 0;
    for (c = 0; buffer[c] != '\0'; c++) {
        if (buffer[c] == d)
            lines += 1;
    } lines += 1; map = malloc(sizeof(char *) * (lines + 2));
    for (; line < lines; line++) {
        map[line] = malloc(sizeof(char) * (my_strlen(buffer)));
        map[line][0] = '\0';
    } return map;
}

int count_lines(char *buffer, char c)
{
    int nbr = 0, index = 0;

    for (; buffer[index]; index++) {
        if (buffer[index] == c) {
            nbr++;
        }
    } return nbr + 1;
}

char **turn_in2_one(char *buffer, char **map, char c)
{
    int index = 0;

if (check_first(buffer, c) == 0) {
        map[0] = buffer;
        map[0][my_strlen(buffer)] = '\0';
        map[1] = NULL;

    } return map;
}

char **turn_in_2d(char *buffer, char c)
{
    int i = 0, col = 0, line = 0;
    char **map = NULL;
    int lines = count_lines(buffer, c) + 1;
    map = allocate_mem(buffer, c);
    if (check_first(buffer, c) == 0) {
        map = turn_in2_one(buffer, map, c);
        return map;
    }
    for (i = 0; buffer[i] != '\0' && line < lines; i++) {
        if (buffer[i] == c) {
            map[line][col] = '\0';
            line += 1; col = 0; i++;
        } if (col < my_strlen(buffer) &&
        map[line] && buffer[i] != '\n') {
            map[line][col] = buffer[i];
            col += 1;
        }
    }
    map[line][col] = '\0'; map[line + 1] = NULL;
    return map;
}
