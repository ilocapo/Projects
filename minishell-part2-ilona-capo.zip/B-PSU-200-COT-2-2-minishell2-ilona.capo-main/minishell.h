/*
** EPITECH PROJECT, 2023
** minishell.h
** File description:
** minishell
*/

#ifndef BSMINISHELL_H_
    #define BSMINISHELL_H_
    #include <unistd.h>
    #include <stdlib.h>
    #include <stdbool.h>
    #include <stdio.h>
    #include <signal.h>
    #include <sys/wait.h>
    #include <dirent.h>
    #include <sys/types.h>
    #include <fcntl.h>

typedef struct env {
    char *env_l;
    struct env *next;
} env_t;

int my_strlen(char *buffer);

char *my_strcpy(char *dest, char const *src);

int check_first(char *buffer, char c);

char *clean_str(char *str);

bool str_compare(char *src, char *str);

int str_ncompare(char *src, char *str, int n);

int my_path(char **env, char *cmd, char **args);

int cols_per_lines(char *buffer, int col, char c);

char **allocate_mem(char *buffer, char d);

int count_lines(char *buffer, char c);

char **turn_in_2d(char *buffer, char c);

int my_putstr(char const *str);

env_t *fill_list(char **env);

env_t *add_at_end(env_t *list, char *n_envl);

char *my_strdup( char const *src );

env_t *set_env(char **path, char **env, env_t *list);

env_t *set_env2(char **path, char **env, env_t *list);

void my_putchar (char c);

env_t *unset_env(char **path, env_t *list);

char *my_strcat (char *dest, char const *src);

void cd_command(char **args, char **env);

env_t *env_command(env_t *list);

void disp_pipe(char **env);

void piper(char **env, char **path, env_t *list);

void conditions(char **path, char *line, char **env, env_t *list);

void exec_command(char **pth, char **env, env_t *list);

void exec_pipe(char **left_pth, char **right_pth, char **env, env_t *list);

void redirect(char **pth);

#endif /* !BSMINISHELL_H_ */
