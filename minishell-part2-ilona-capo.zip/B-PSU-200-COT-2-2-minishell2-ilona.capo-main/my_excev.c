/*
** EPITECH PROJECT, 2023
** my_excev.c
** File description:
** step_4
*/

#include "minishell.h"

void conditions(char **path, char *line, char **env, env_t *list)
{
    int check = 0; if (path[0] == NULL) { my_putstr("$> ");
    } if (str_compare(path[0], "cd") == true) {
        cd_command(path, env);
    } if (str_compare(path[0], "env") == true && path[1] == NULL) {
        list = env_command(list);
    } if (str_compare(path[0], "env") == true && path[1] != NULL) {
        my_putstr("env: ‘"); my_putstr(path[1]);
        my_putstr("’: No such file or directory\n");
    } if (str_compare(path[0], "setenv") == true &&
    path[1] != NULL && path[2] != NULL) {
        list = set_env(path, env, list);
    } if (str_compare(path[0], "setenv") == true &&
    path[1] == NULL && path[2] == NULL) {
        list = env_command(list);
    } if (str_compare(path[0], "setenv") == true &&
    path[1] != NULL && path[2] == NULL) {
        list = set_env2(path, env, list);
    } if (str_compare(path[0], "unsetenv") == true) {
        list = unset_env(path, list);
    } check = my_path(env, line, path);
}

void do_pipe(char **cms, char **env, env_t *list)
{
cms[0] = clean_str(cms[0]); cms[1] = clean_str(cms[1]);
            char **cm1 = turn_in_2d(cms[0], ' ');
            char **cm2 = turn_in_2d(cms[1], ' ');
            exec_pipe(cm1, cm2, env, list);
}

void check_line(char **cms, char **env, char **pth, env_t *list)
{
    if (cms[0] != NULL && cms[1] == NULL) {
        cms[0] = clean_str(cms[0]);
        pth = turn_in_2d(cms[0], ' ');
        int pid = getpid(), new_pid = fork(), status;
    if (new_pid == 0) {
        redirect(pth);
        conditions(pth, pth[0], env, list);
    }
    new_pid != 0 && new_pid != -1 ? waitpid(new_pid, &status, 0) : (0);
    new_pid == -1 ? write(2, "Binnary/Command not found\n", 26) : (0);
    } else if (cms[0] != NULL && cms[1] != NULL) {
        do_pipe(cms, env, list);
    } else {};
}

void disp_prompt(char **env)
{
    int read = 0; size_t len = 0;
    char *line = NULL; env_t *list = fill_list(env);
    int index = 0; char **pth, **path;
    while ((read != -1)) {
        my_putstr("$> "); read = getline(&line, &len, stdin);
        line = clean_str(line);
        path = turn_in_2d(line, ';');
        for (index = 0; path[index] != NULL; index++) {
        path[index] = clean_str(path[index]);
        char **cms = turn_in_2d(path[index], '|');
        check_line(cms, env, path, list);
        }
    }
}

int main(int ac, char **av, char **env)
{
    disp_prompt(env);
    return 0;
}
