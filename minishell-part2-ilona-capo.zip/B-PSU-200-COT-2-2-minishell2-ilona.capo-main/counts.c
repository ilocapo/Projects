/*
** EPITECH PROJECT, 2023
** counts.c
** File description:
** counts
*/

#include "minishell.h"

int my_strlen(char *buffer)
{
    int index = 0, len = 0;

    for (index = 0; buffer[index] != '\0'; index++) {
        len++;
    } return len;
}

int cols_per_lines(char *buffer, int col, char c)
{
    int i = 0, j = 0;
    for (i = col; buffer[i] != c; i++, j++);
    return j;
}

int check_first(char *buffer, char c)
{
    int index = 0;
    for (index = 0; buffer[index] != '\0'; index++) {
        if (buffer[index] == c) {
            return 1;
        }
    } return 0;
}
