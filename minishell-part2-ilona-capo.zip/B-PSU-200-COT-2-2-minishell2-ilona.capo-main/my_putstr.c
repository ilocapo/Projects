/*
** EPITECH PROJECT, 2023
** my_putstr.c
** File description:
** my_putstr
*/

#include "minishell.h"

void my_putchar(char c)
{
    write(1, &c, 1);
}

int my_putstr(char const *str)
{
    int index = 0;
    for (index = 0; str[index] != '\0'; index++) {
        write(1, &(str[index]), 1);
    }
}
