/*
** EPITECH PROJECT, 2023
** my_strcpy.c
** File description:
** my_strcpy
*/

#include "minishell.h"

char *my_strcpy(char *dest, char const *src)
{
    int i = 0;
    for (i = 0; src[i] != '\0'; ++i) {
        dest[i] = src[i];
    } dest[i] = '\0';
    return dest;
}

char *my_strdup( char const *src )
{
    char *str;
    str = malloc(sizeof(char) * (sizeof(src) + 1));
    int i;
    for (i = 0; src[i] != '\0'; ++i){
        str[i] = src[i];
    }
    str[i] = '\0';
    return str;
}
