/*
** EPITECH PROJECT, 2023
** clean_string.c
** File description:
** A program to clean additional space in a string
*/

#include "minishell.h"

int is_a_space(char c)
{
    return c == ' ' || c == '\t' || c == '\n';
}

char *clean_str(char *str)
{
    int len = my_strlen(str);
    int countor = 0;
    char *cleaned = malloc(sizeof(char) * (len) + 7);
    cleaned[0] = '\0';

    if (len > 0) {
        if (!is_a_space(str[0])) {
            cleaned[countor] = str[0];
            countor++;
        } for (int i = 1; i < len; i++) {
            if (!is_a_space(str[i]) ||
            (is_a_space(str[i]) && !is_a_space(str[i - 1]))) {
                cleaned[countor] = str[i]; countor++;
            }
        }
    } if (cleaned[countor - 1] == ' ') {
        cleaned[countor - 1] = '\0';
    } else {
    cleaned[countor] = '\0';
    } return cleaned;
}
