/*
** EPITECH PROJECT, 2023
** my_excec_pipe.c
** File description:
** my_excec_pipe
*/

#include "minishell.h"

void piper(char **env, char **path, env_t *list)
{
    int index = 0;
    char **pth;
    int fd[2];
    int p = pipe(fd);
    int nw_fd = dup2(fd[0], 1);
    for (index = 0; path[index] != NULL; index++) {
        pth = turn_in_2d(path[index], ' ');
        int pid = getpid(), new_pid = fork(), status, check = 0;
        if (new_pid == 0) {
            conditions(pth, pth[0], env, list);
        } new_pid != 0 && new_pid != -1 ? dup2(fd[0], 0),
        waitpid(new_pid, &status, 0) : (0);
        new_pid == -1 ? write(2, "Fork error\n", 12) : (0);
    }
}

void disp_pipe(char **env)
{
    int read = 0; size_t len = 0; char *line = NULL;
    env_t *list = fill_list(env); int index = 0;
    char **pth, **path; while ((read != -1)) {
        my_putstr("$> "); read = getline(&line, &len, stdin);
        line = clean_str(line);
        path = turn_in_2d(line, ';');
        for (index = 0; path[index] != NULL; index++) {
        pth = turn_in_2d(path[index], '|');
        piper(env, pth, list);
    }
    } if (line); free(line);
}
