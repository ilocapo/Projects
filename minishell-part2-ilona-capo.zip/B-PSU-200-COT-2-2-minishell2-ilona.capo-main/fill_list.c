/*
** EPITECH PROJECT, 2023
** fill_list.c
** File description:
** fill_list
*/

#include "minishell.h"

env_t *add_at_end(env_t *list, char *n_envl)
{
    int index = 0;
    env_t *cpy = malloc(sizeof(env_t));
    if (list == NULL) {
        cpy->env_l = n_envl;
        cpy->next = NULL;
        return cpy;
    }
    env_t *tmp = malloc(sizeof(env_t));
    tmp = list;
    while (tmp->next != NULL) {
        tmp = tmp->next;
    }
    cpy->env_l = n_envl;
    cpy->next = NULL;
    tmp->next = cpy;
    return list;
}

env_t *fill_list(char **env)
{
    env_t *list = malloc(sizeof(env_t) + 1);
    list = NULL;
    int index = 0;
    while (env[index] != NULL) {
        list = add_at_end(list, env[index]);
        index++;
    }
    return list;
}
