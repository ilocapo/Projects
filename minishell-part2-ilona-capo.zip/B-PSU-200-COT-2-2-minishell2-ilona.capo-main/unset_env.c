/*
** EPITECH PROJECT, 2023
** unset_env.c
** File description:
** unset_env
*/

#include "minishell.h"

env_t *unset_env(char **path, env_t *list)
{
    char *val = malloc(sizeof(char) * my_strlen(path[1]) + 1);
    env_t *unset = malloc(sizeof(env_t));
    unset = list;
    int index = 0;
    val = path[1];
    for (index = 0; !str_ncompare(unset->env_l,
    val, my_strlen(path[1])); unset = unset->next){};
    unset = unset->next->next;
    return unset;
}
