/*
** EPITECH PROJECT, 2023
** st_compare.c
** File description:
** A function to compare two string
*/

#include "minishell.h"

bool str_compare(char *src, char *str)
{
    int i = 0;
    for ( i = 0; src[i] != '\0' && str[i] != '\0'; ++i){
        if (src[i] != str[i]){
            return false;
        }
    }
    return src[i] == '\0' && str[i] == '\0';
}

int str_ncompare(char *src, char *str, int n)
{
    int i = 0;
    for (i = 0; i < n && src[i] == str[i]; i++){
    }
    return src[n - 1] - str[i - 1];
}
