#!/bin/bash
 read $1
git add . 
git commit -m $1
git push origin main
