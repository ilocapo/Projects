/*
** EPITECH PROJECT, 2023
** inter_cone.c
** File description:
** inter_cone
*/

#include "my_header.h"

void inter_cone(fig_t fig, vector_t direct)
{
Point origin = {0, 0, 0}; double delta, t1, t2; Point sec1, sec2;
double cost = cos(fig.param * PI / 180), sint = sin(fig.param * PI / 180);
double a1 = direct.x * direct.x + direct.y * direct.y - direct.z * direct.z *
tan(fig.param * PI / 180) * tan(fig.param * PI / 180); double b1 = 2 *
(direct.x * (fig.point.x - origin.x) + direct.y * (fig.point.y - origin.y) -
direct.z * (fig.point.z - origin.z) * tan(fig.param * PI / 180) * tan(fig.param
* PI / 180)); double c1 = pow((fig.point.x - origin.x), 2) + pow((fig.point.y -
origin.y), 2) - pow((fig.point.z -origin.z), 2) * tan(fig.param * PI / 180) *
tan(fig.param * PI / 180); delta = b1 * b1 - 4 * a1 * c1; if (delta < 0) {
printf("No intersection point.\n"); } else if (delta == 0) { double t = -b1
/ (2 * a1); sec1.x = origin.x + t * direct.x; sec1.y = origin.y + t * direct.y;
sec1.z = origin.z + t * direct.z; printf("1 intersection point:\n");
disp_point(sec1); } else { t1 = (-b1 + sqrt(delta)) / (2 * a1); t2 = (-b1 -
sqrt(delta)) / (2 * a1); sec1.x = origin.x + t1 * direct.x; sec1.y = origin.y +
t1 * direct.y; sec1.z = fig.point.z + t1 * direct.z; sec2.x = origin.x + t2 *
direct.x; sec2.y = origin.y + t2 * direct.y; sec2.z = fig.point.z + t2 *
direct.z; printf("2 intersection points:\n"); disp_point(sec1);
disp_point(sec2);
}
}
