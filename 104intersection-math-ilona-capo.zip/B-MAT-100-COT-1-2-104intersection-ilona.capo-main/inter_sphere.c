/*
** EPITECH PROJECT, 2023
** inter_sphere.c
** File description:
** inter_sphere
*/

#include "my_header.h"

void inter_sphere(fig_t fig, vector_t direct)
{
Point origin = {0, 0, 0}; double a, b, c, delta, t1, t2;
Point sec1, sec2;
a = direct.x * direct.x + direct.y * direct.y + direct.z * direct.z;
b = 2 * (direct.x * (fig.point.x - origin.x) + direct.y *
(fig.point.y - origin.y) + direct.z * (fig.point.z - origin.z));
c = pow((fig.point.x - origin.x), 2) + pow((fig.point.y - origin.y), 2)
+ pow((fig.point.z - origin.z), 2) - pow(fig.param, 2); delta = (b * b)
- (4 * a * c); if (delta < 0) { printf("No intersection point.\n");
} else if (delta == 0) {
double t = -b / (2 * a);
sec1.x = fig.point.x + t * direct.x; sec1.y = fig.point.y + t * direct.y;
sec1.z = fig.point.z + t * direct.z; printf("1 intersection point:\n");
disp_point(sec1); } else {
t1 = (-b + sqrt(delta)) / (2 * a); t2 = (-b - sqrt(delta)) / (2 * a);
sec1.x = fig.point.x + t1 * direct.x; sec1.y = fig.point.y + t1 * direct.y;
sec1.z = fig.point.z + t1 * direct.z; sec2.x = fig.point.x + t2 * direct.x;
sec2.y = fig.point.y + t2 * direct.y; sec2.z = fig.point.z + t2 * direct.z;
printf("2 intersection points:\n"); disp_point(sec1); disp_point(sec2);
    }
}
