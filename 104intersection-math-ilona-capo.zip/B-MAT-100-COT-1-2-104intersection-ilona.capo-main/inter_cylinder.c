/*
** EPITECH PROJECT, 2023
** inter_cylinder.c
** File description:
** inter_cylinder
*/

#include "my_header.h"

void inter_cylinder(fig_t fig, vector_t direct)
{
Point sec1, sec2, origin = {0, 0, 0};
double a, b, c, delta, t1, t2;
a = direct.x * direct.x + direct.y * direct.y;
b = 2 * (direct.x * (fig.point.x - origin.x) + direct.y *
(fig.point.y - origin.y)); c = pow((fig.point.x - origin.x), 2) +
pow((fig.point.y - origin.y), 2) - pow(fig.param, 2); delta = b * b
- 4 * a * c; if (delta < 0) { printf("No intersection point.\n");
} else if (delta == 0) {
double t = -b / (2 * a); sec1.x = origin.x + t * direct.x; sec1.y =
origin.y + t * direct.y; sec1.z = fig.point.z + t * direct.z;
printf("1 intersection point:\n"); disp_point(sec1);
} else { t1 = (-b + sqrt(delta)) / (2 * a); t2 = (-b - sqrt(delta)) / (2 * a);
sec1.x = origin.x + t1 * direct.x; sec1.y = origin.y + t1 * direct.y;
sec1.z = fig.point.z + t1 * direct.z; sec2.x = origin.x + t2 * direct.x;
sec2.y = origin.y + t2 * direct.y; sec2.z = fig.point.z + t2 * direct.z;
printf("2 intersection points:\n"); disp_point(sec1); disp_point(sec2);
}
}
