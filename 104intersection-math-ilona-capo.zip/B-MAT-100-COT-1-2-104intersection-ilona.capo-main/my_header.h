/*
** EPITECH PROJECT, 2023
** my_header.h
** File description:
** 104_header
*/

#ifndef MY_HEADER_H_
    #define MY_HEADER_H_
    #define PI 3.14159265358979323846
    #include <stdio.h>
    #include <stdlib.h>
    #include <math.h>

typedef struct {
    double x;
    double y;
    double z;
} Point;

typedef struct {
    double x;
    double y;
    double z;
} vector_t;

typedef struct {
    int type;
    Point point;
    vector_t vect;
    double param;
} fig_t;

void inter_sphere(fig_t fig, vector_t direct) ;

void disp_point(Point point);

void inter_cylinder(fig_t fig, vector_t direct);

void inter_cone(fig_t fig, vector_t direct);

void disp_usage(int ac, char **av);

#endif /* !104_HEADER_H_ */
