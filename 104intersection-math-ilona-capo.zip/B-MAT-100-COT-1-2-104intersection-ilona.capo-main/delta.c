/*
** EPITECH PROJECT, 2023
** delta.c
** File description:
** A function to return the delta of an equation
*/

#include "my_header.h"

void disp_point(Point point)
{
    printf("(%.3f, %.3f, %.3f)\n", point.x, point.y, point.z);
}

void inter_se(fig_t fig, char **av)
{
    vector_t direct = fig.vect;
    int xp = atoi(av[2]), yp = atoi(av[3]), zp = atoi(av[4]),
    xv = atoi(av[5]), yv = atoi(av[6]), zv = atoi(av[7]);
    if (fig.type == 1) {
        printf("Sphere of a radius %d\n", atoi(av[8]));
        printf("Line passing trough the point (%d, %d, %d) an parallel to the vector (%d, %d, %d)\n", xp, yp, zp, xv, yv, zv);
        inter_sphere(fig, direct);
    } else if (fig.type == 2) {
        printf("Cylinder of a radius %d\n", atoi(av[8]));
        printf("Line passing trough the point (%d, %d, %d) an parallel to the vector (%d, %d, %d)\n", xp, yp, zp, xv, yv, zv);
        inter_cylinder(fig, direct);
        } else if (fig.type == 3) {
        printf("Cone with a %d degree angle\n", atoi(av[8]));
        printf("Line passing trough the point (%d, %d, %d) an parallel to the vector (%d, %d, %d)\n", xp, yp, zp, xv, yv, zv);
        inter_cone(fig, direct);
        }
}

int main(int ac, char** av)
{
if (ac != 9 && ac != 2) {
printf("Invalid number of arguments.\n");
return 84;
} if ((ac == 2) && av[1][0] == '-' && av[1][1] == 'h') {
disp_usage(ac, av);}
fig_t fig;
fig.type = atoi(av[1]); fig.point.x = atof(av[2]);
fig.point.y = atof(av[3]); fig.point.z = atof(av[4]);
fig.vect.x = atof(av[5]); fig.vect.y = atof(av[6]);
fig.vect.z = atof(av[7]); fig.param = atof(av[8]);
inter_se(fig, av); return 0;
}
