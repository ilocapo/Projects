/*
** EPITECH PROJECT, 2023
** disp_usage.c
** File description:
** disp_usage
*/

#include "my_header.h"

void disp_usage(int ac, char **av)
{
    printf("USAGE\n   ./104intersection opt xp yp zp xv yv zv p\n\n");
    printf("DESCRIPTION\n    opt\t\t   surface option:");
    printf(" 1 for a sphere, 2 for a cylinder, 3 for a cone\n    ");
    printf("(xp, yp, zp)   coordinates of a point by wich the light ray passes trough\n    ");
    printf("(xv, yv, zv)   coordinates of a vector parallel to the light ray\n    ");
    printf("p              parameter: radius of the sphere, radius of the cylinder, or\n");
    printf("                   angle formed by the one and the Z-axis\n");
}
