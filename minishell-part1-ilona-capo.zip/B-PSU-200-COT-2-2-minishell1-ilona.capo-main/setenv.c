/*
** EPITECH PROJECT, 2023
** setenv.c
** File description:
** setenv
*/

#include "minishell.h"

void setenv_command(char **env, char **args)
{
    while (*env) {
        my_putstr(*env);
        my_putchar('\n');
        env++;
    }
env_t *elem = malloc(sizeof(env_t));
add_at_beg(args[1], args[2], elem);
my_putchar('\n');
my_putstr(elem->elem1);
my_putchar('=');
my_putstr(elem->elem2);
}
