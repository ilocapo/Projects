/*
** EPITECH PROJECT, 2023
** my_excev.c
** File description:
** step_4
*/

#include "minishell.h"
#include <stdio.h>

void conditions(char **path, char *line, char **env)
{
    int check = 0;
    if (path[0] == NULL) {
        my_putstr("$> ");
    } if (str_compare(path[0], "cd") == true) {
        cd_command(path, env);
    } if (str_compare(path[0], "env") == true) {
        env_command(env);
    } check = my_path(env, line, path);
}

void disp_prompt(char **env)
{
    int read = 0;
    size_t len = 0;
    char *line = NULL;

    while ((read != -1)) {
        my_putstr("$> "); read = getline(&line, &len, stdin);
        line = clean_str(line);
        char **path = turn_in_2d(line, ' ');
        int pid = getpid(), new_pid = fork(), status, check = 0;
        if (new_pid == 0) {
            conditions(path, line, env);
        } new_pid != 0 && new_pid != -1 ? waitpid(new_pid, &status, 0) : (0);
        new_pid == -1 ? write(2, "Binnary/Command not found\n", 26) : (0);
    } if (line); free(line);
}

int main(int ac, char **av, char **env)
{
    disp_prompt(env);
    return 0;
}
