/*
** EPITECH PROJECT, 2023
** minishell.h
** File description:
** minishell
*/

#ifndef BSMINISHELL_H_
    #define BSMINISHELL_H_
    #include <unistd.h>
    #include <stdlib.h>
    #include <stdbool.h>
    #include <stdio.h>
    #include <signal.h>
    #include <sys/wait.h>
    #include <dirent.h>
    #include <sys/types.h>
    #include <fcntl.h>

int my_strlen(char *buffer);

char *my_strcpy(char *dest, char const *src);


char *clean_str(char *str);

bool str_compare(char *src, char *str);

int str_ncompare(char *src, char *str, int n);

int my_path(char **env, char *cmd, char **args);

int cols_per_lines(char *buffer, int col, char c);

char **allocate_mem(char *buffer, char d);

int count_lines(char *buffer, char c);

char **turn_in_2d(char *buffer, char c);

int my_putstr(char const *str);

void my_putchar (char c);

int my_putnbr(int nb);

char *my_strcat (char *dest, char const *src);

void cd_command(char **args, char **env);

void env_command(char **env);

#endif /* !BSMINISHELL_H_ */
