/*
** EPITECH PROJECT, 2023
** print_env.c
** File description:
** print_env
*/

#include "minishell.h"

void modif(char *buff)
{
    for (int k = 0; buff[k] != '\0'; k++) {
        if (buff[k] == '\n') {
            buff[k] = '\0';
        }
    } for (int k = 0; buff[k] != '\0'; k++) {
        if (buff[k] == ' ') {
            buff[k] = '\0';
        }
    }
}

void my_exec(char *cmd, char **args, char **env, char *path_tab)
{
    if (str_compare(cmd, "cd") == false &&
        str_compare(cmd, "env") == false &&
        str_compare(cmd, "setenv") == false &&
        str_compare(cmd, "unsetenv") == false &&
        str_compare(cmd, "exit") == false) {
        execve(path_tab, args, env);
    }
}

void my_exec_other(char *cmd)
{
    if (str_compare(cmd, "cd") == false &&
        str_compare(cmd, "env") == false &&
        str_compare(cmd, "setenv") == false &&
        str_compare(cmd, "unsetenv") == false &&
        str_compare(cmd, "exit") == false) {
        my_putstr(cmd);
        my_putstr(": Command not found.\n");
    }
}

char *find_path(char **env)
{
    int i = 0;
    char *temp = malloc(sizeof(char) * 95);
    for (i = 0; env[i] != NULL; i++) {
        if (!str_ncompare("PATH=/", env[i], 6)) {
            temp = my_strcpy(temp, env[i]);
            break;
        }
    } return temp;
}

int my_path(char **env, char *cmd, char **args)
{
    char *path = find_path(env);
    char **path_tab = turn_in_2d(path, ':');
    char *path_temp = malloc(sizeof(char) * 21);
    int index = 0, ind = 0;
    for (index = 5; path_tab[0][index] != '\0'; index++) {
    path_temp[ind] = path_tab[0][index]; ind++;
    } path_tab[0] = path_temp;
    int is_x = 0; modif(cmd);
    if (access(cmd, X_OK)) {
        args[0] = cmd; execve(cmd, args, env);
    } for (int i = 0; path_tab[i] != NULL; i++) {
        path_tab[i] = my_strcat(path_tab[i], "/");
        path_tab[i] = my_strcat(path_tab[i], cmd);
        args[0] = path_tab[i];
        if (access(path_tab[i], X_OK) == 0) {
            my_exec(cmd, args, env, path_tab[i]);
        }
    } if (access(cmd, X_OK)) {
        execve(cmd, path_tab, env);
    } my_exec_other(cmd); return 0;
}
