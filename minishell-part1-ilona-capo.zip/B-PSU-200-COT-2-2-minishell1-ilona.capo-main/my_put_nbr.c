/*
** EPITECH PROJECT, 2023
** my_put_nbr.c
** File description:
** my_put_nbr.c
*/

#include <stdio.h>
#include <string.h>
#include <unistd.h>

void my_putchar(char c);

int my_putnbr(int nb)
{
    if (nb >= 0 && nb < 10) {
        my_putchar(nb + 48);
    } else if (nb < 0) {
        my_putchar('-');
        my_putnbr(nb * (-1));
    } else{
        my_putnbr(nb / 10);
        my_putnbr(nb % 10);
    }
    return 0;
}
