/*
** EPITECH PROJECT, 2023
** turn_in2d.c.c
** File description:
** turn in 2d
*/

#include "minishell.h"

int my_strlen(char *buffer)
{
    int index = 0, len = 0;

    for (index = 0; buffer[index]; index++) {
        len++;
    } return len;
}

int cols_per_lines(char *buffer, int col, char c)
{
    int i = 0, j = 0;
    for (i = col; buffer[i] != c; i++, j++);
    return j;
}

char **allocate_mem(char *buffer, char d)
{
    char **map = NULL;
    int lines = 0, line = 0, col = 0, cols = 0, c = 0;
    for (c = 0; buffer[c] != '\0'; c++) {
        if (buffer[c] == d)
            lines += 1;
    } lines += 1; map = malloc(sizeof(char *) * (lines + 1));
    for (; line < lines; line++) {
        map[line] = malloc(sizeof(char) * (my_strlen(buffer) + 1));
    } return map;
}

int count_lines(char *buffer, char c)
{
    int nbr = 0, index = 0;

    for (; buffer[index]; index++) {
        if (buffer[index] == c) {
            nbr++;
        }
    } return nbr + 1;
}

char **turn_in_2d(char *buffer, char c)
{
    int i = 0, col = 0, line = 0;
    char **map = NULL;
    int lines = count_lines(buffer, c) + 1;
    map = allocate_mem(buffer, c);
    for (i = 0; buffer[i] != '\0' && line < lines; i++) {
        if (buffer[i] == c) {
            map[line][col + 1] = '\0';
            line += 1;
            col = 0;
            i++;
        } if (col < my_strlen(buffer) &&
        map[line] && buffer[i] != '\n') {
            map[line][col] = buffer[i];
            col += 1;
        }
    }
    map[line + 1] = NULL;
    return map;
}
