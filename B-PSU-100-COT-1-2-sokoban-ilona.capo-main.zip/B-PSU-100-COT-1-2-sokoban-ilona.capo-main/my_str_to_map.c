/*
** EPITECH PROJECT, 2023
** my_str_to_map.c
** File description:
** Functions to turn the content of a file into a map
*/

#include "my_sokoban.h"

char *open_file(char **av)
{
    char *buffer;
    int fd = 0; ssize_t size = 0;
    struct stat info;
    stat(av[1], &info);
    fd = open(av[1], O_RDONLY);
    if (fd == -1) exit(84);
    buffer = malloc(sizeof(char) * (info.st_size + 1));
    size = read(fd, buffer, info.st_size);
    if (size == -1) exit (84);
    buffer[size] = '\0';
    close(fd);
    return buffer;
}

int cols_per_lines(char *buffer, int col)
{
    int i = 0, j = 0;
    for (i = col; buffer[i] != '\n'; i++, j++);
    return j;
}

char **allocate_mem(char *buffer)
{
char **map;
    int lines = 0, line = 0, col = 0, cols = 0, c = 0;
    for (c = 0; buffer[c] != '\0'; c++) {
        if ( buffer[c] == '\n')
            lines += 1;
    }
    map = malloc(sizeof(char *) * (lines + 1));
    for (; line < lines; line++) {
        cols = cols_per_lines(buffer, col);
        map[line] = malloc(sizeof(char) * (cols + 2));
        col += (cols + 1);
    }
    return map;
}

char **turn_in_2d(char *buffer)
{
    int i = 0, col = 0, line = 0;
    char **map = NULL;
    map = allocate_mem(buffer);
    for (i = 0; buffer[i] != '\0'; i++){
        if (buffer[i] == '\n') {
            map[line][col] = '\n';
            map[line][col + 1] = '\0';
            line += 1;
            col = 0;
        } else {
            map[line][col] = buffer[i];
            col += 1;
        }
    }
map[line] = NULL; return map;
}
