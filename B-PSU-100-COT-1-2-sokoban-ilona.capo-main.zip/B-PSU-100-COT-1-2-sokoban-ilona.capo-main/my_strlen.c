/*
** EPITECH PROJECT, 2023
** my_strlen.c
** File description:
** my_strlen
*/
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int my_strlen ( char const *str )
{
    int i = 0;
    for (i = 0; str[i] != '\0'; ++i){
    };
        return (i);
}
