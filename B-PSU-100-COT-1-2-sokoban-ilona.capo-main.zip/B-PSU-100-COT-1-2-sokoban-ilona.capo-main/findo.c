/*
** EPITECH PROJECT, 2023
** findo.c
** File description:
** findo
*/

#include "my_sokoban.h"

char **verif_map(char **map_src, char **map_modif)
{
    for (int line = 0; map_src[line]; line++) {
        for (int col = 0; map_src[line][col]; col++) {
        map_src[line][col] == 'O' && map_modif[line][col] == ' ' ?
        map_modif[line][col] = 'O' : (0);
        }
    } return map_modif;
}

int count_char(char **map, char c)
{
    int nbr = 0;
    for (int line = 0; map[line]; line++) {
        for (int col = 0; map[line][col]; col++) {
            map[line][col] == c ? nbr += 1 : (0);
        }
    } return nbr;
}

int verif_win (char **map_src, char **map_modif)
{
    int nbr_o = count_char(map_src, 'O');
    int nbr_x = count_char(map_src, 'X');
    int check = 0;
    for (int line = 0; map_src[line]; line++) {
        for (int col = 0; map_src[line][col]; col++) {
        map_src[line][col] == 'O' && map_modif[line][col] == 'X' ?
        check += 1 : (0);
        }
    }
    if (check == nbr_o) {
        return 0;
    }
    return 1;
}
