/*
** EPITECH PROJECT, 2023
** my_sokoban.h
** File description:
** A header for my sokoban
*/

#ifndef MY_SOKOBAN_H_
    #define MY_SOKOBAN_H_
    #include <ncurses.h>
    #include <stdlib.h>
    #include <sys/types.h>
    #include <sys/stat.h>
    #include <fcntl.h>
    #include <unistd.h>
    #include <stdio.h>

typedef struct position {
    int x;
    int y;
}pos_t;

typedef struct findo {
    int row;
    int col;
    struct findo *next;
} poso_t;

int verif_win (char **map_src, char **map_modif);

char **verif_map(char **map_src, char **map_modif);

void disp_usage(int ac, char **av);

int my_strlen(char const *str);

char *open_file(char **av);

int cols_per_lines(char *buffer, int col);

char **allocate_mem(char *buffer);

char **turn_in_2d(char *buffer);

int go_right(char**map, int x, int y);

int go_left(char**map, int x, int y);

int go_down(char**map, int x, int y);

int go_up(char**map, int x, int y);

int count_char(char **map, char c);

int **get_pos_o(char **map);

pos_t get_pos_x(char *buffer);

int blocked(char *buffer);

#endif /* !MY_SOKOBAN_H_ */
