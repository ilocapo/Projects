/*
** EPITECH PROJECT, 2023
** window.c
** File description:
** A program to print Hello wrold on a window in ncurses
*/

#include "my_sokoban.h"

pos_t get_pos(char *buffer)
{
    pos_t pos = {0, 0};
    int i = 0, j = 0, col = 0;
    for (i = 0; buffer[i] != '\0'; i++) {
        if ( buffer[i] == '\n'){
        j++;
        col = 0;
        }if (buffer[i] == 'P'){
            pos.x = col - 1;
            pos.y = j;
        }
        col++;
        if ( buffer[i] != ' ' && buffer[i] != '#' && buffer[i] != 'P' &&
        buffer[i] != '\n' && buffer[i] != 'O' && buffer[i] != 'X')
        exit (84);
    }
    return pos;
}

char *my_popup(char **map, char *buffer)
{
    int j = 0; pos_t pos = get_pos(buffer); int x = pos.x, y = pos.y;
    char **map_s = turn_in_2d(buffer);
    initscr(); keypad(stdscr, true); while (1) {
    clear(); while (map[j] != NULL) { mvprintw(j , 0, map[j]); j += 1;
} j = 0; switch (getch()){ case KEY_RIGHT:
    x = go_right(map, x, y); break; case KEY_LEFT:
    x = go_left(map, x, y); break; case KEY_DOWN:
    y = go_down(map, x, y); break; case KEY_UP:
    y = go_up(map, x, y); break; case ' ': endwin(); return 0;
    mvprintw(j , 0, map[j]); j += 1; break;
} map = verif_map(map_s, map); refresh(); int win = verif_win(map_s,
map); if (win == 0) { endwin(); return 0;
}
    } endwin(); return 0;
}

int main (int ac, char **av)
{
    if ( ac != 2) exit (84);
    if ( ac == 2 && av[1][0] == '-' && av[1][1] == 'h'){
    disp_usage(ac , av);
    }else{
    char *buffer = open_file(av);
    char **map = turn_in_2d(buffer);
    my_popup(map, buffer);
    free(map);
    return 0;
    }

}
