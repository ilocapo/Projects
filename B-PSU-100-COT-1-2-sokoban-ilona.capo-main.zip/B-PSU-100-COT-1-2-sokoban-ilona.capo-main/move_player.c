/*
** EPITECH PROJECT, 2023
** move_player.c
** File description:
** Functions to manage the moove of my player
*/

#include "my_sokoban.h"

int go_right(char **map, int x, int y)
{
    switch (map[y][x + 1]) {
        case 'X':
        if (map[y][x + 2] != '#' && map[y][x + 2] != 'X') {
            if (map[y][x + 2] == 'O') {
            map[y][x] = ' '; map[y][x + 1] = 'P'; map[y][x + 2] = 'X'; x++;
            } else {
                map[y][x] = ' '; map[y][x + 1] = 'P'; map[y][x + 2] = 'X'; x++;
            }
        }break;
    case ' ':
        map[y][x] = ' '; map[y][x + 1] = 'P';
        x += 1;
    break;
    case 'O':
    if (map[y][x + 2] != '#' && map[y][x + 2] != 'X' && map[y][x + 2] != 'O'){
    map[y][x] = ' ';
    map[y][x + 1] = 'P';
    x++;
    }break;
    } return x;
}

int go_left(char **map, int x, int y)
{
    switch (map[y][x - 1]){
        case 'X':
            if (map[y][x - 2] != '#' && map[y][x - 2] != 'X') {
                if (map[y][x - 2] == 'O') {
                map[y][x] = ' '; map[y][x - 1] = 'P'; map[y][x - 2] = 'X'; x--;
                } else {
                map[y][x] = ' '; map[y][x - 1] = 'P'; map[y][x - 2] = 'X'; x--;
            }
        }break;
    case ' ':
        map[y][x] = ' '; map[y][x - 1] = 'P';
        x--; break;
    case 'O':
    if (map[y][x - 2] != '#' && map[y][x - 2] != 'X' && map[y][x - 2] != 'O'){
    map[y][x] = ' '; map[y][x - 1] = 'P';
    x--;
    } break;
    } return x;
}

int go_down(char **map, int x, int y)
{
    switch (map[y + 1][x]){
    case 'X':
        if (map[y + 2][x] != '#' && map[y + 2][x] != 'X') {
            if (map[y + 2][x] == 'O') {
                map[y][x] = ' '; map[y + 1][x] = 'P';
                map[y + 2][x] = 'X'; y++;
            } else {
                map[y][x] = ' '; map[y + 1][x] = 'P';
                map[y + 2][x] = 'X'; y++;
            }
        }break;
    case ' ':
        map[y][x] = ' '; map[y + 1][x] = 'P';
        y++; break;
    case 'O':
        if (map[y + 2][x] != '#' && map[y + 2][x] != 'X'){
        map[y][x] = ' '; map[y + 1][x] = 'P';
    y++;
    } break;
    } return y;
}

int go_up(char **map, int x, int y)
{
    switch (map[y - 1][x]){
        case 'X':
        if (map[y - 2][x] != '#' && map[y - 2][x] != 'X') {
            if (map[y - 2][x] == 'O') {
                map[y][x] = ' '; map[y - 1][x] = 'P';
                map[y - 2][x] = 'X'; y--;
            } else {
                map[y][x] = ' '; map[y - 1][x] = 'P';
                map[y - 2][x] = 'X'; y--;
            }
        }break;
    case ' ':
        map[y][x] = ' '; map[y - 1][x] = 'P';
        y--; break;
    case 'O':
        if (map[y - 2][x] != '#' && map[y - 2][x] != 'X'){
    map[y][x] = ' '; map[y - 1][x] = 'P';
    y--;
    } break;
    } return y;
}
