/*
** EPITECH PROJECT, 2023
** display_usage.c
** File description:
** A function for the usage's display
*/

#include "my_sokoban.h"

void disp_usage(int ac, char **av)
{
    if ((ac == 2) & (av[1][0] == '-') && (av[1][1] == 'h')){
write(1, "USAGE\n", 6);
write(1, "     ./my_soban map\n", 21);
write(1, "DESCRIPTION\n", 12);
write(1, "     map  file representing the warehouse map,", 47);
write(1, "containing '#' for walls,\n", 26);
write(1, "\t  'P' for the player, 'X' for boxes and '0' for storage ", 58);
write(1, "locations.", 10);
    }
}
