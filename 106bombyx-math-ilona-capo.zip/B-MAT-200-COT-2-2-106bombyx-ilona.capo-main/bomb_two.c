/*
** EPITECH PROJECT, 2023
** bomb_two.c
** File description:
** bomb_two
*/

#include "bombyx_header.h"

void bomb_two(float n, float i0, float i1)
{
    double k = 1;
    int count = 1;
    for (k = 100; k <= 400; k += 1) {
        for (count = 1; count <= i1; count++) {
        n = ((((double)(k / 100) * n) * (1000 - n)) / (1000));
        count >= i0 && count <= i1 ? printf("%.2f %.2f\n", (double)(k / 100), n) :
        (0);
        }
    }
}
