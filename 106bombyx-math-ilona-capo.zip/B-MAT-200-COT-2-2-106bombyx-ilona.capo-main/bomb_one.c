/*
** EPITECH PROJECT, 2023
** bomb_one.c
** File description:
** bomb_one
*/

#include "bombyx_header.h"

void bomb_one(double n, double k)
{
    int count = 1;
    printf("%d %.2f\n", count, n);
    for (count = 2; count <= 100; count++) {
        n = (k * n * (1000 - n)) / (1000);
        printf("%d %.2f\n", count, n);
    }
}

int main (int ac, char **av)
{
    if (ac == 2 && av[1][0] == '-' && av[1][1] == 'h') {
        disp_usage();
        return 0;
    }
    if (ac == 3) {
    double n = atof(av[1]);
    double k = atof(av[2]);
    if (k >= 1 && k <= 4 && n > 0) {
    bomb_one(n, k);
    return 0;
    } return 84;
    } if (ac == 4) {
    float i0 = atof(av[2]);
    float i1 = atof(av[3]);
    float n = atof(av[1]);
    if (n > 0 && i0 < i1) {
    bomb_two(n, i0, i1);
    return 0;
    } return 84;
    } return 84;
}
