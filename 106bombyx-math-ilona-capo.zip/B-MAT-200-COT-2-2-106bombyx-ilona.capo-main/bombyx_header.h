/*
** EPITECH PROJECT, 2023
** bombyx_header.h
** File description:
** bombyx_header
*/

#ifndef BOMBYX_HEADER_H_
    #define BOMBYX_HEADER_H_
    #include <math.h>
    #include <stdio.h>
    #include <unistd.h>
    #include <stdlib.h>

void disp_usage(void);

void bomb_two(float n, float i0, float i1);

void bomb_one(double n, double k);

#endif /* !BOMBYX_HEADER_H_ */
