/*
** EPITECH PROJECT, 2023
** verif_arguments.c
** File description:
** A programm to verify arguments
*/

int verif_char(char c)
{
    if (c != ' ' && c != '-') {
        if (c < 'A' || (c >= '[' && c < 'a') || c >= '{') {
        return 1;
        }
    }
    return 0;
}

int verif_arg(char *str)
{
    int index = 0;
    int check = verif_char(str[index]);

    for (index = 0; str[index] != '\0'; index++) {
        check = verif_char(str[index]);
        if (check == 1) {
            return 1;
        }
    }
    return 0;
}

int verif_space(char *str)
{
    int index = 0;

    for (index = 0; str[index] != '\0'; index++) {
        if (str[index] == ' ') {
            return 0;
        }
    }
    return 1;
}
