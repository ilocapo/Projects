/*
** EPITECH PROJECT, 2023
** my_putstr.c
** File description:
** A function to write string
*/

#include <unistd.h>

void my_putstr(char *str)
{
    int index = 0;

    for (index = 0; str[index] != '\0'; index++) {
        write(1, &(str[index]), 1);
    }
}
