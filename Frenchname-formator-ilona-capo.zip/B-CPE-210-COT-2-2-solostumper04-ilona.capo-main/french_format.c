/*
** EPITECH PROJECT, 2023
** french_format.c
** File description:
** A program to put in frecnh format names
*/

#include <unistd.h>

void my_putstr(char *str);

char *in_upc(char *str)
{
    int index = 0;

    for (index = 0; str[index] != '\0'; index++) {
        if (str[index] >= 'a' && str[index] <= 'z') {
            str[index] = str[index] - 32;
        }
    }
    return str;
}

int has_tiret(char *str)
{
    int check = 0;
    int index = 0;

    for (index = 0; str[index] != ' '; index++) {
        if (str[index] == '-') {
            return index + 1;
        }
    }
    return 0;
}

char *in_lowc(char *str, int index, char c)
{

    for (index += 1; str[index] != c; index++) {
        if (str[index] >= 'A' && str[index] <= 'Z') {
                str[index] = str[index] + 32;
            }
    }
    return str;
}

void french_format(char *str)
{
    int check = has_tiret(str);

    str = in_upc(str);
    if (check != 0) {
        str = in_lowc(str, 0, '-');
        str = in_lowc(str, check, ' ');
        my_putstr(str);
    }
    if (check == 0) {
        str = in_lowc(str, 0, ' ');
        my_putstr(str);
    }
}

int main (int ac, char **av)
{
    char line = '\n';

    if (ac != 2) {
        write(2, "Usage: ", 7);
        write(2, "frenchNameFormatter ", 20);
        write(2, "string\n", 7);
        return 84;
    }
    french_format(av[1]);
    write(1, &line, 1);
    return 0;
}
